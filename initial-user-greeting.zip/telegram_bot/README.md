# Watermark Telegram Bot (Pure Python)

A Telegram bot that stamps a customizable watermark (text or logo image) onto
**any photo, video, GIF or document** - including large files (2GB+, the
maximum Telegram itself allows for a bot account). Built entirely in Python
with [Pyrogram](https://docs.pyrogram.org/) (MTProto, so it isn't limited by
the 20/50MB HTTP Bot API caps), Pillow for images and ffmpeg for video.

No HTML / CSS / JavaScript anywhere - this is a standalone Python service,
completely independent from the Next.js placeholder app that lives in the
rest of this repository (that app is only here because the hosting sandbox
requires it; it is not used by the bot in any way).

## Features

- **Text or logo watermarks** - type any text or upload any image/logo.
- **Fully configurable via `/settings`** (stored per user in Postgres):
  - Watermark text
  - Font (10 bundled open-source fonts: Poppins, Oswald, Anton, Bebas Neue,
    Pacifico, Lobster, Dancing Script, Open Sans, Courier Stamp...)
  - Color (10 presets or any custom HEX code)
  - Size (percent of the media's shorter side)
  - Opacity (1-100%)
  - Position (top-left/right, bottom-left/right, center, random)
  - **Animation**: `None`, `📀 DVD Bounce` (the watermark bounces around and
    reflects off every edge, just like the DVD logo screensaver),
    `➡️ Slide In`, `🌫 Fade In`
- **Large file support (2GB+)** - media is streamed to/from disk in chunks
  (never loaded fully into memory), with a live animated progress bar
  (percentage, speed, ETA) while downloading, processing and uploading.
- Works with photos, videos, GIFs/animations, video notes, and image/video
  documents.

## 1. Requirements

- Python 3.10+
- `ffmpeg` and `ffprobe` on the `PATH` (used for video watermarking):
  ```bash
  sudo apt-get update && sudo apt-get install -y ffmpeg
  ```
- A PostgreSQL database (the repo already has one configured via
  `DATABASE_URL` in `.env`; the bot reuses it for settings storage).
- A Telegram **API ID** and **API Hash** from <https://my.telegram.org>
  ("API Development Tools").
- A **Bot Token** from [@BotFather](https://t.me/BotFather).

## 2. Install dependencies

From the project root:

```bash
pip install -r requirements.txt
```

## 3. Configure credentials

Open the project's root `.env` file and fill in the placeholders:

```
API_ID=123456
API_HASH=abcdef1234567890abcdef1234567890
BOT_TOKEN=123456789:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
```

Optional tuning variables are also available in `.env`:

- `ADMIN_IDS` - comma separated Telegram user IDs allowed to run `/stats`.
- `BOT_WORKERS` - concurrent update workers (default `8`).
- `BOT_MAX_CONCURRENT_TRANSMISSIONS` - concurrent up/downloads (default `4`).
- `MAX_FILE_SIZE_MB` - hard cap enforced by the bot itself (default `4000`).

## 4. Run the bot

From the project root:

```bash
python -m telegram_bot.main
```

On first run Pyrogram will create a local session file
(`telegram_bot/watermark_bot.session`) - keep it, it lets the bot restart
without re-authenticating.

## 5. Using the bot

1. Open a chat with your bot on Telegram and send `/start`.
2. Send `/settings` to open the configuration panel and set your watermark
   text/logo, font, color, size, opacity, position and animation.
3. Send any photo, video, GIF or document - the bot downloads it, applies
   your watermark (showing a live progress bar), then uploads the result
   back to you.

### Commands

| Command     | Description                                   |
|-------------|------------------------------------------------|
| `/start`    | Welcome message                                |
| `/settings` | Open the watermark settings panel              |
| `/cancel`   | Cancel whatever input the bot is waiting for   |
| `/help`     | Show usage help                                |
| `/stats`    | (admins only) show global usage stats          |

## Project layout

```
telegram_bot/
├── main.py                 # entry point (python -m telegram_bot.main)
├── bot.py                  # shared Pyrogram Client instance
├── config.py                # env var loading
├── constants.py             # fonts / colors / positions / animations / defaults
├── db.py                     # Postgres (asyncpg) settings storage
├── fonts/                    # bundled open-source .ttf fonts
├── handlers/
│   ├── start.py              # /start /help /cancel /stats
│   ├── settings.py           # /settings + inline keyboard callback logic
│   ├── text_input.py         # captures custom text/color/size/opacity replies
│   └── media.py               # downloads, watermarks, uploads media
├── watermark/
│   ├── image_watermark.py     # Pillow-based watermarking for photos
│   └── video_watermark.py     # ffmpeg-based watermarking for videos/GIFs
└── utils/
    ├── position.py             # shared position/animation math (incl. DVD bounce)
    ├── ffmpeg_utils.py         # async ffmpeg/ffprobe wrappers with progress
    ├── progress.py              # animated progress bar renderer
    ├── keyboards.py             # inline keyboard builders
    └── formatting.py            # settings summary text
```

## Notes on large files (2GB+)

Pyrogram talks to Telegram's MTProto servers directly (not the restrictive
HTTPS Bot API), so this bot can send/receive files up to Telegram's own
platform limit - **2GB for regular accounts, 4GB if the bot is run with a
Telegram Premium session**. There is no additional size limit imposed by this
code (beyond the configurable `MAX_FILE_SIZE_MB` safety cap). Large files are
always streamed to/from disk through `telegram_bot/downloads` and
`telegram_bot/outputs`, which are cleaned up automatically after every job.
