from __future__ import annotations

import re

from pyrogram import filters
from pyrogram.types import CallbackQuery, Message

from telegram_bot.bot import PENDING_INPUT, app
from telegram_bot.constants import COLORS
from telegram_bot.db import get_settings, reset_settings, update_settings
from telegram_bot.handlers.start import HELP_TEXT
from telegram_bot.utils.formatting import settings_summary
from telegram_bot.utils.keyboards import (
    animation_keyboard,
    cancel_keyboard,
    color_keyboard,
    font_keyboard,
    main_menu_keyboard,
    opacity_keyboard,
    position_keyboard,
    size_keyboard,
)

CALLBACK_PATTERN = re.compile(
    r"^(m|close|reset|help|mode:(text|image)|pos:(menu|[a-z_]+)|anim:(menu|[a-z_]+)|"
    r"font:(menu|[a-z_]+)|color:(menu|custom|[a-z]+)|size:(menu|custom|\d+)|"
    r"opacity:(menu|custom|\d+)|text:ask|logo:ask)$"
)


@app.on_message(filters.command("settings") & filters.private)
async def settings_cmd(client, message: Message):
    settings = await get_settings(message.from_user.id)
    await message.reply_text(settings_summary(settings), reply_markup=main_menu_keyboard(settings))


@app.on_callback_query(filters.regex(CALLBACK_PATTERN))
async def settings_callback(client, cq: CallbackQuery):
    user_id = cq.from_user.id
    data = cq.data

    if data == "help":
        await cq.answer()
        await cq.message.edit_text(HELP_TEXT)
        return

    if data == "m":
        settings = await get_settings(user_id)
        await cq.message.edit_text(settings_summary(settings), reply_markup=main_menu_keyboard(settings))
        await cq.answer()
        return

    if data == "close":
        await cq.message.edit_text(
            "\u2705 Settings saved. Send me any photo, video, GIF or document to watermark it!"
        )
        await cq.answer("Saved")
        return

    if data == "reset":
        settings = await reset_settings(user_id)
        await cq.message.edit_text(settings_summary(settings), reply_markup=main_menu_keyboard(settings))
        await cq.answer("Reset to defaults")
        return

    if data.startswith("mode:"):
        mode = data.split(":", 1)[1]
        settings = await update_settings(user_id, mode=mode)
        await cq.message.edit_text(settings_summary(settings), reply_markup=main_menu_keyboard(settings))
        await cq.answer(f"Mode set to {mode}")
        return

    if data == "pos:menu":
        settings = await get_settings(user_id)
        await cq.message.edit_text(settings_summary(settings), reply_markup=position_keyboard(settings))
        await cq.answer()
        return

    if data.startswith("pos:"):
        value = data.split(":", 1)[1]
        settings = await update_settings(user_id, position=value)
        await cq.message.edit_text(settings_summary(settings), reply_markup=position_keyboard(settings))
        await cq.answer("Position updated")
        return

    if data == "anim:menu":
        settings = await get_settings(user_id)
        await cq.message.edit_text(settings_summary(settings), reply_markup=animation_keyboard(settings))
        await cq.answer()
        return

    if data.startswith("anim:"):
        value = data.split(":", 1)[1]
        settings = await update_settings(user_id, animation=value)
        await cq.message.edit_text(settings_summary(settings), reply_markup=animation_keyboard(settings))
        await cq.answer("Animation updated")
        return

    if data == "font:menu":
        settings = await get_settings(user_id)
        await cq.message.edit_text(settings_summary(settings), reply_markup=font_keyboard(settings))
        await cq.answer()
        return

    if data.startswith("font:"):
        value = data.split(":", 1)[1]
        settings = await update_settings(user_id, font=value)
        await cq.message.edit_text(settings_summary(settings), reply_markup=font_keyboard(settings))
        await cq.answer("Font updated")
        return

    if data == "color:menu":
        settings = await get_settings(user_id)
        await cq.message.edit_text(settings_summary(settings), reply_markup=color_keyboard(settings))
        await cq.answer()
        return

    if data == "color:custom":
        PENDING_INPUT[user_id] = "color"
        await cq.message.edit_text(
            "\U0001f3a8 Send me a HEX color code, e.g. `#FF00AA` or `#39FF14`.",
            reply_markup=cancel_keyboard(),
        )
        await cq.answer()
        return

    if data.startswith("color:"):
        key = data.split(":", 1)[1]
        hexval = COLORS.get(key)
        if hexval:
            settings = await update_settings(user_id, color=hexval)
            await cq.message.edit_text(settings_summary(settings), reply_markup=color_keyboard(settings))
            await cq.answer("Color updated")
        return

    if data == "size:menu":
        settings = await get_settings(user_id)
        await cq.message.edit_text(settings_summary(settings), reply_markup=size_keyboard(settings))
        await cq.answer()
        return

    if data == "size:custom":
        PENDING_INPUT[user_id] = "size"
        await cq.message.edit_text(
            "\U0001f4cf Send me the watermark size as a percentage of the media's "
            "shorter side (1-40), e.g. `7`.",
            reply_markup=cancel_keyboard(),
        )
        await cq.answer()
        return

    if data.startswith("size:"):
        value = int(data.split(":", 1)[1])
        settings = await update_settings(user_id, size=value)
        await cq.message.edit_text(settings_summary(settings), reply_markup=size_keyboard(settings))
        await cq.answer("Size updated")
        return

    if data == "opacity:menu":
        settings = await get_settings(user_id)
        await cq.message.edit_text(settings_summary(settings), reply_markup=opacity_keyboard(settings))
        await cq.answer()
        return

    if data == "opacity:custom":
        PENDING_INPUT[user_id] = "opacity"
        await cq.message.edit_text(
            "\U0001f4a7 Send me the opacity percentage (1-100), e.g. `85`.",
            reply_markup=cancel_keyboard(),
        )
        await cq.answer()
        return

    if data.startswith("opacity:"):
        value = int(data.split(":", 1)[1])
        settings = await update_settings(user_id, opacity=value)
        await cq.message.edit_text(settings_summary(settings), reply_markup=opacity_keyboard(settings))
        await cq.answer("Opacity updated")
        return

    if data == "text:ask":
        PENDING_INPUT[user_id] = "text"
        await cq.message.edit_text(
            "\u270f\ufe0f Send me the watermark text you want to use (max 60 characters).",
            reply_markup=cancel_keyboard(),
        )
        await cq.answer()
        return

    if data == "logo:ask":
        PENDING_INPUT[user_id] = "logo"
        await cq.message.edit_text(
            "\U0001f5bc\ufe0f Send me the image (as a photo or image document) you "
            "want to use as your logo watermark.",
            reply_markup=cancel_keyboard(),
        )
        await cq.answer()
        return

    await cq.answer()
