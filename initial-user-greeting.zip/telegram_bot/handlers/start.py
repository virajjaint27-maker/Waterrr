from __future__ import annotations

from pyrogram import filters
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, Message

from telegram_bot.bot import PENDING_INPUT, app
from telegram_bot.config import ADMIN_IDS
from telegram_bot.db import global_stats

WELCOME_TEXT = (
    "\U0001f4a7 *Watermark Bot*\n\n"
    "Send me *any photo, video, GIF or document* and I will stamp it with your "
    "custom watermark - text or logo, any color, any font, any position, even "
    "animated like a bouncing DVD logo.\n\n"
    "Works with large files too (2GB+, depending on Telegram limits).\n\n"
    "\u2699\ufe0f Use /settings to customize everything before you send media.\n"
    "\u2753 Use /help to see all commands."
)

HELP_TEXT = (
    "*Commands*\n\n"
    "/settings - open the watermark settings panel\n"
    "/cancel - cancel whatever input I'm currently waiting for\n"
    "/help - show this message\n\n"
    "*How it works*\n"
    "1. Configure your watermark with /settings (text or logo image, color, "
    "font, size, opacity, position and animation).\n"
    "2. Send me a photo, video, GIF or video/image document.\n"
    "3. I download it, stamp the watermark on it (with a live progress bar) "
    "and send it back.\n\n"
    "*Animations*\n"
    "\U0001f4c0 DVD Bounce - the watermark bounces around the frame and reflects "
    "off every edge, exactly like the classic DVD screensaver.\n"
    "\u27a1\ufe0f Slide In - the watermark slides in from off-screen and settles in place.\n"
    "\U0001f32b Fade In - the watermark fades in from transparent to its target opacity.\n"
    "(Animations apply to videos/GIFs; photos always use a static position.)"
)


@app.on_message(filters.command("start") & filters.private)
async def start_cmd(client, message: Message):
    await message.reply_text(
        WELCOME_TEXT,
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton("\u2699\ufe0f Settings", callback_data="m"),
                    InlineKeyboardButton("\u2753 Help", callback_data="help"),
                ]
            ]
        ),
    )


@app.on_message(filters.command("help") & filters.private)
async def help_cmd(client, message: Message):
    await message.reply_text(HELP_TEXT)


@app.on_message(filters.command("cancel") & filters.private)
async def cancel_cmd(client, message: Message):
    PENDING_INPUT.pop(message.from_user.id, None)
    await message.reply_text("\u2705 Cancelled. Send /settings to continue configuring your watermark.")


@app.on_message(filters.command("stats") & filters.private)
async def stats_cmd(client, message: Message):
    if ADMIN_IDS and message.from_user.id not in ADMIN_IDS:
        await message.reply_text("\u26d4 You are not authorized to use this command.")
        return
    stats = await global_stats()
    await message.reply_text(
        "\U0001f4ca *Bot stats*\n\n"
        f"Users: `{stats.get('users', 0)}`\n"
        f"Files processed: `{stats.get('files_processed', 0)}`\n"
        f"Bytes processed: `{stats.get('bytes_processed', 0)}`"
    )
