"""Handles incoming photos / videos / GIFs / documents: downloads them (with a
live progress bar, no matter how large), applies the user's configured
watermark, then uploads the result back - all streamed to/from disk so even
2GB+ files never need to fit in memory."""
from __future__ import annotations

import asyncio
import uuid
from pathlib import Path

from pyrogram import filters
from pyrogram.types import Message

from telegram_bot.bot import PENDING_INPUT, app
from telegram_bot.config import DOWNLOADS_DIR, MAX_FILE_SIZE_BYTES, OUTPUTS_DIR
from telegram_bot.db import get_settings, record_usage, update_settings
from telegram_bot.utils.ffmpeg_utils import ensure_ffmpeg_available
from telegram_bot.utils.formatting import settings_summary
from telegram_bot.utils.keyboards import main_menu_keyboard
from telegram_bot.utils.progress import ProgressTracker, human_size
from telegram_bot.watermark.image_watermark import apply_image_watermark
from telegram_bot.watermark.video_watermark import apply_video_watermark

MEDIA_FILTER = filters.private & (
    filters.photo | filters.video | filters.animation | filters.document | filters.video_note
)


def _get_file_size(message: Message) -> int:
    for attr in ("video", "animation", "document", "video_note", "audio"):
        obj = getattr(message, attr, None)
        if obj is not None and getattr(obj, "file_size", None):
            return obj.file_size
    if message.photo:
        return message.photo.file_size or 0
    return 0


@app.on_message(MEDIA_FILTER)
async def handle_media(client, message: Message):
    user_id = message.from_user.id
    pending = PENDING_INPUT.get(user_id)

    # --- Logo upload flow (user tapped "Upload Logo Image" in /settings) ---
    if pending == "logo":
        file_id = None
        if message.photo:
            file_id = message.photo.file_id
        elif message.document and (message.document.mime_type or "").startswith("image/"):
            file_id = message.document.file_id

        if not file_id:
            await message.reply_text(
                "\u26a0\ufe0f Please send an image (as a photo or image document) to use as your logo watermark."
            )
            return

        await update_settings(user_id, logo_file_id=file_id, mode="image")
        PENDING_INPUT.pop(user_id, None)
        settings = await get_settings(user_id)
        await message.reply_text(
            "\u2705 Logo saved as your watermark!\n\n" + settings_summary(settings),
            reply_markup=main_menu_keyboard(settings),
        )
        return

    settings = await get_settings(user_id)
    if settings.get("mode") == "image" and not settings.get("logo_file_id"):
        await message.reply_text(
            "\u26a0\ufe0f You're in Logo mode but haven't uploaded a logo yet.\n"
            "Open /settings \u2192 \U0001f5bc\ufe0f Upload Logo Image, or switch to Text mode."
        )
        return

    doc = message.document
    doc_mime = (doc.mime_type or "") if doc else ""
    is_image = bool(message.photo) or doc_mime.startswith("image/")
    is_video = bool(message.video or message.animation or message.video_note) or doc_mime.startswith("video/")

    if not is_image and not is_video:
        await message.reply_text(
            "\u26a0\ufe0f Unsupported file type. Send a photo, video, GIF, or an image/video document."
        )
        return

    file_size = _get_file_size(message)
    if file_size and file_size > MAX_FILE_SIZE_BYTES:
        await message.reply_text(
            f"\u26a0\ufe0f This file is {human_size(file_size)}, larger than the "
            f"{human_size(MAX_FILE_SIZE_BYTES)} limit Telegram currently allows for bots."
        )
        return

    work_id = uuid.uuid4().hex[:10]
    user_dl_dir = DOWNLOADS_DIR / str(user_id)
    user_out_dir = OUTPUTS_DIR / str(user_id)
    user_dl_dir.mkdir(parents=True, exist_ok=True)
    user_out_dir.mkdir(parents=True, exist_ok=True)

    status = await message.reply_text("\u2b07\ufe0f Starting download\u2026", quote=True)

    input_path = None
    logo_path = None
    output_path = None
    try:
        tracker = ProgressTracker(status, "Downloading media")
        input_path = await client.download_media(
            message,
            file_name=str(user_dl_dir / f"in_{work_id}"),
            progress=tracker.update,
        )

        if settings.get("mode") == "image" and settings.get("logo_file_id"):
            logo_path = await client.download_media(
                settings["logo_file_id"], file_name=str(user_dl_dir / f"logo_{work_id}")
            )

        await status.edit_text("\u2699\ufe0f Applying watermark\u2026")

        info = None
        if is_video:
            ensure_ffmpeg_available()
            out_path = str(user_out_dir / f"out_{work_id}.mp4")
            tracker2 = ProgressTracker(status, "Applying watermark (encoding video)")
            info = await apply_video_watermark(
                input_path, out_path, settings, logo_path=logo_path, tracker=tracker2
            )
            output_path = out_path
        else:
            ext = Path(input_path).suffix.lower() or ".jpg"
            out_path = str(user_out_dir / f"out_{work_id}{ext}")
            await asyncio.to_thread(apply_image_watermark, input_path, out_path, settings, logo_path)
            output_path = out_path

        await status.edit_text("\u2b06\ufe0f Uploading result\u2026")
        tracker3 = ProgressTracker(status, "Uploading result")

        if is_video:
            await client.send_video(
                message.chat.id,
                output_path,
                caption="\u2705 Watermarked",
                supports_streaming=True,
                width=info.width if info else None,
                height=info.height if info else None,
                duration=int(info.duration) if info else None,
                progress=tracker3.update,
                reply_to_message_id=message.id,
            )
        else:
            await client.send_document(
                message.chat.id,
                output_path,
                caption="\u2705 Watermarked",
                force_document=True,
                progress=tracker3.update,
                reply_to_message_id=message.id,
            )

        await record_usage(user_id, file_size or 0)
        await status.delete()
    except Exception as exc:  # noqa: BLE001 - surface any failure to the user
        try:
            await status.edit_text(f"\u274c Something went wrong while processing your media:\n`{exc}`")
        except Exception:
            pass
    finally:
        for p in (input_path, logo_path, output_path):
            if p:
                try:
                    Path(p).unlink(missing_ok=True)
                except Exception:
                    pass
