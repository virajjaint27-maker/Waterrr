from __future__ import annotations

import re

from pyrogram import filters
from pyrogram.types import Message

from telegram_bot.bot import PENDING_INPUT, app
from telegram_bot.db import get_settings, update_settings
from telegram_bot.utils.formatting import settings_summary
from telegram_bot.utils.keyboards import cancel_keyboard, main_menu_keyboard

HEX_RE = re.compile(r"^#?[0-9A-Fa-f]{6}$")


@app.on_message(filters.text & filters.private & ~filters.via_bot & ~filters.command([
    "start", "settings", "help", "cancel", "stats"
]))
async def handle_pending_text(client, message: Message):
    user_id = message.from_user.id
    pending = PENDING_INPUT.get(user_id)

    if not pending:
        await message.reply_text(
            "\U0001f44b Send /settings to customize your watermark, or just send me a "
            "photo, video, GIF or document and I'll stamp your current watermark on it."
        )
        return

    value = message.text.strip()

    if pending == "text":
        if len(value) == 0 or len(value) > 60:
            await message.reply_text(
                "\u26a0\ufe0f Text must be between 1 and 60 characters. Try again.",
                reply_markup=cancel_keyboard(),
            )
            return
        await update_settings(user_id, text=value)

    elif pending == "color":
        if not HEX_RE.match(value):
            await message.reply_text(
                "\u26a0\ufe0f That doesn't look like a valid hex color. Send something "
                "like `#FF00AA`.",
                reply_markup=cancel_keyboard(),
            )
            return
        normalized = "#" + value.lstrip("#").upper()
        await update_settings(user_id, color=normalized)

    elif pending == "size":
        if not value.isdigit() or not (1 <= int(value) <= 40):
            await message.reply_text(
                "\u26a0\ufe0f Send a whole number between 1 and 40.",
                reply_markup=cancel_keyboard(),
            )
            return
        await update_settings(user_id, size=int(value))

    elif pending == "opacity":
        if not value.isdigit() or not (1 <= int(value) <= 100):
            await message.reply_text(
                "\u26a0\ufe0f Send a whole number between 1 and 100.",
                reply_markup=cancel_keyboard(),
            )
            return
        await update_settings(user_id, opacity=int(value))

    PENDING_INPUT.pop(user_id, None)
    settings = await get_settings(user_id)
    await message.reply_text(
        "\u2705 Updated!\n\n" + settings_summary(settings), reply_markup=main_menu_keyboard(settings)
    )
