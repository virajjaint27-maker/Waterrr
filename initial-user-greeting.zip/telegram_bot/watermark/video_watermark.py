"""Applies a text or logo watermark (optionally animated, e.g. DVD bounce)
to a video using ffmpeg."""
from __future__ import annotations

import tempfile
from pathlib import Path
from typing import Any, Optional

from telegram_bot.config import FONTS_DIR
from telegram_bot.constants import FONTS
from telegram_bot.utils.ffmpeg_utils import MediaInfo, probe, run_ffmpeg_with_progress
from telegram_bot.utils.position import (
    build_fade_alpha_expr,
    build_ffmpeg_xy_expr,
    hex_to_ffmpeg_color,
    resolve_position,
)
from telegram_bot.utils.progress import ProgressTracker


async def apply_video_watermark(
    input_path: str,
    output_path: str,
    settings: dict[str, Any],
    logo_path: Optional[str] = None,
    tracker: Optional[ProgressTracker] = None,
) -> MediaInfo:
    info = await probe(input_path)
    opacity_fraction = max(0.0, min(1.0, settings.get("opacity", 70) / 100))
    animation = settings.get("animation", "none")
    position = resolve_position(settings.get("position", "bottom_right"))

    args: list[str] = ["-i", input_path]
    tmp_textfile: Optional[Path] = None

    if settings.get("mode") == "image" and logo_path:
        args += ["-i", logo_path]
        logo_w = max(16, int(info.width * (settings.get("size", 5) * 3) / 100))
        x_expr, y_expr = build_ffmpeg_xy_expr(position, animation, "W", "H", "w", "h")

        overlay_chain = f"[1:v]scale={logo_w}:-1,format=rgba,colorchannelmixer=aa={opacity_fraction:.3f}"
        if animation == "fade":
            overlay_chain += ",fade=t=in:st=0:d=1.5:alpha=1"
        overlay_chain += "[wm]"

        filter_complex = (
            f"{overlay_chain};"
            f"[0:v][wm]overlay=x={x_expr}:y={y_expr}:shortest=1:format=auto[v]"
        )
        args += ["-filter_complex", filter_complex, "-map", "[v]"]
    else:
        text = (settings.get("text") or "@YourBrand").strip() or "@YourBrand"
        font_file = FONTS_DIR / FONTS.get(settings.get("font", "poppins_bold"), FONTS["poppins_bold"])[1]
        font_size = max(10, int(min(info.width, info.height) * settings.get("size", 5) / 100))
        color = hex_to_ffmpeg_color(settings.get("color", "#FFFFFF"))

        x_expr, y_expr = build_ffmpeg_xy_expr(position, animation, "w", "h", "text_w", "text_h")

        tmp_fd = tempfile.NamedTemporaryFile(
            mode="w", suffix=".txt", delete=False, encoding="utf-8"
        )
        tmp_fd.write(text)
        tmp_fd.close()
        tmp_textfile = Path(tmp_fd.name)

        drawtext_opts = [
            f"fontfile='{font_file.as_posix()}'",
            f"textfile='{tmp_textfile.as_posix()}'",
            f"fontsize={font_size}",
            f"fontcolor={color}",
            "borderw=2",
            "bordercolor=0x000000@0.45",
            f"x={x_expr}",
            f"y={y_expr}",
        ]
        if animation == "fade":
            drawtext_opts.append(f"alpha='{build_fade_alpha_expr(opacity_fraction)}'")
        else:
            drawtext_opts[3] = f"fontcolor={color}@{opacity_fraction:.3f}"

        filter_str = "drawtext=" + ":".join(drawtext_opts)
        args += ["-vf", filter_str]

    args += [
        "-c:v",
        "libx264",
        "-preset",
        "veryfast",
        "-crf",
        "22",
        "-pix_fmt",
        "yuv420p",
    ]
    if info.has_audio:
        args += ["-c:a", "aac", "-b:a", "192k"]
    else:
        args += ["-an"]
    args += ["-movflags", "+faststart", output_path]

    try:
        await run_ffmpeg_with_progress(args, info.duration, tracker=tracker, prefix="Applying watermark")
    finally:
        if tmp_textfile is not None and tmp_textfile.exists():
            tmp_textfile.unlink(missing_ok=True)

    return info
