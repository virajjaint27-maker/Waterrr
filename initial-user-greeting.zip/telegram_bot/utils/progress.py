"""Helpers for rendering animated progress bars inside edited Telegram messages."""
from __future__ import annotations

import time
from typing import Optional

from pyrogram.errors import FloodWait, MessageNotModified

BAR_LENGTH = 14
SPINNER_FRAMES = ["\u25d0", "\u25d3", "\u25d1", "\u25d2"]


def human_size(num: float) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if num < 1024.0:
            return f"{num:3.1f} {unit}"
        num /= 1024.0
    return f"{num:.1f} PB"


def render_bar(percent: float, length: int = BAR_LENGTH) -> str:
    percent = max(0.0, min(100.0, percent))
    filled = int(length * percent / 100)
    return "\u2593" * filled + "\u2591" * (length - filled)


class ProgressTracker:
    """Throttled progress reporter usable both as a Pyrogram download/upload
    callback and as a manual updater for ffmpeg processing."""

    def __init__(self, message, prefix: str, min_interval: float = 2.5):
        self.message = message
        self.prefix = prefix
        self.min_interval = min_interval
        self.start_time = time.monotonic()
        self._last_edit = 0.0
        self._last_percent = -1.0
        self._frame = 0

    async def _safe_edit(self, text: str) -> None:
        try:
            await self.message.edit_text(text)
        except MessageNotModified:
            pass
        except FloodWait as exc:
            time.sleep(min(exc.value, 10))
        except Exception:
            pass

    async def update(self, current: int, total: int) -> None:
        now = time.monotonic()
        percent = (current / total * 100) if total else 0.0
        significant_change = abs(percent - self._last_percent) >= 2 or percent >= 100
        if now - self._last_edit < self.min_interval and not significant_change:
            return
        self._last_edit = now
        self._last_percent = percent
        elapsed = max(now - self.start_time, 0.001)
        speed = current / elapsed
        eta = (total - current) / speed if speed > 0 else 0
        self._frame = (self._frame + 1) % len(SPINNER_FRAMES)
        spinner = SPINNER_FRAMES[self._frame]
        text = (
            f"{spinner} {self.prefix}\n\n"
            f"[{render_bar(percent)}] {percent:5.1f}%\n"
            f"{human_size(current)} / {human_size(total)}\n"
            f"\u26a1 {human_size(speed)}/s \u2022 \u23f3 ETA {int(eta)}s"
        )
        await self._safe_edit(text)

    async def finish(self, text: str) -> None:
        await self._safe_edit(text)

    def sync_callback(self, loop):
        """Returns a Pyrogram-compatible progress callback (sync wrapper is not
        needed since Pyrogram supports async progress callbacks directly)."""

        async def _cb(current: int, total: int):
            await self.update(current, total)

        return _cb
