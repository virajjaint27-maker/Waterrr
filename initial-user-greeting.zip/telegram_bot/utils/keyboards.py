"""Inline keyboard builders for the /settings menu tree."""
from __future__ import annotations

from typing import Any

from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from telegram_bot.constants import ANIMATIONS, COLORS, FONTS, OPACITY_PRESETS, POSITIONS, SIZE_PRESETS


def _mark(label: str, selected: bool) -> str:
    return f"\u2705 {label}" if selected else label


def main_menu_keyboard(settings: dict[str, Any]) -> InlineKeyboardMarkup:
    mode = settings.get("mode", "text")
    rows = [
        [
            InlineKeyboardButton(_mark("\U0001f170\ufe0f Text Mode", mode == "text"), callback_data="mode:text"),
            InlineKeyboardButton(_mark("\U0001f5bc\ufe0f Logo Mode", mode == "image"), callback_data="mode:image"),
        ],
    ]
    if mode == "text":
        rows.append(
            [InlineKeyboardButton(f"\u270f\ufe0f Text: {settings.get('text', '')[:20]}", callback_data="text:ask")]
        )
        rows.append(
            [
                InlineKeyboardButton("\U0001f524 Font", callback_data="font:menu"),
                InlineKeyboardButton("\U0001f3a8 Color", callback_data="color:menu"),
            ]
        )
    else:
        rows.append([InlineKeyboardButton("\U0001f5bc\ufe0f Upload Logo Image", callback_data="logo:ask")])

    rows.append(
        [
            InlineKeyboardButton("\U0001f4cf Size", callback_data="size:menu"),
            InlineKeyboardButton("\U0001f4a7 Opacity", callback_data="opacity:menu"),
        ]
    )
    rows.append(
        [
            InlineKeyboardButton("\U0001f4cd Position", callback_data="pos:menu"),
            InlineKeyboardButton("\U0001f3ac Animation", callback_data="anim:menu"),
        ]
    )
    rows.append(
        [
            InlineKeyboardButton("\U0001f504 Reset Defaults", callback_data="reset"),
            InlineKeyboardButton("\u2714\ufe0f Done", callback_data="close"),
        ]
    )
    return InlineKeyboardMarkup(rows)


def back_row(target: str = "m") -> list[InlineKeyboardButton]:
    return [InlineKeyboardButton("\u2b05\ufe0f Back", callback_data=target)]


def position_keyboard(settings: dict[str, Any]) -> InlineKeyboardMarkup:
    current = settings.get("position")
    rows = []
    items = list(POSITIONS.items())
    for i in range(0, len(items), 2):
        row = []
        for key, label in items[i : i + 2]:
            row.append(InlineKeyboardButton(_mark(label, current == key), callback_data=f"pos:{key}"))
        rows.append(row)
    rows.append(back_row())
    return InlineKeyboardMarkup(rows)


def animation_keyboard(settings: dict[str, Any]) -> InlineKeyboardMarkup:
    current = settings.get("animation")
    rows = []
    for key, label in ANIMATIONS.items():
        rows.append([InlineKeyboardButton(_mark(label, current == key), callback_data=f"anim:{key}")])
    rows.append(back_row())
    return InlineKeyboardMarkup(rows)


def font_keyboard(settings: dict[str, Any]) -> InlineKeyboardMarkup:
    current = settings.get("font")
    rows = []
    items = list(FONTS.items())
    for i in range(0, len(items), 2):
        row = []
        for key, (label, _file) in items[i : i + 2]:
            row.append(InlineKeyboardButton(_mark(label, current == key), callback_data=f"font:{key}"))
        rows.append(row)
    rows.append(back_row())
    return InlineKeyboardMarkup(rows)


def color_keyboard(settings: dict[str, Any]) -> InlineKeyboardMarkup:
    current = (settings.get("color") or "").upper()
    rows = []
    items = list(COLORS.items())
    for i in range(0, len(items), 2):
        row = []
        for key, hexval in items[i : i + 2]:
            selected = current == hexval.upper()
            row.append(InlineKeyboardButton(_mark(f"\u25cf {key.title()}", selected), callback_data=f"color:{key}"))
        rows.append(row)
    rows.append([InlineKeyboardButton("\U0001f3a8 Custom HEX", callback_data="color:custom")])
    rows.append(back_row())
    return InlineKeyboardMarkup(rows)


def size_keyboard(settings: dict[str, Any]) -> InlineKeyboardMarkup:
    current = settings.get("size")
    rows = [[]]
    for preset in SIZE_PRESETS:
        rows[0].append(InlineKeyboardButton(_mark(f"{preset}%", current == preset), callback_data=f"size:{preset}"))
    rows.append([InlineKeyboardButton("\u2699\ufe0f Custom", callback_data="size:custom")])
    rows.append(back_row())
    return InlineKeyboardMarkup(rows)


def opacity_keyboard(settings: dict[str, Any]) -> InlineKeyboardMarkup:
    current = settings.get("opacity")
    rows = [[]]
    for preset in OPACITY_PRESETS:
        rows[0].append(
            InlineKeyboardButton(_mark(f"{preset}%", current == preset), callback_data=f"opacity:{preset}")
        )
    rows.append([InlineKeyboardButton("\u2699\ufe0f Custom", callback_data="opacity:custom")])
    rows.append(back_row())
    return InlineKeyboardMarkup(rows)


def cancel_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[InlineKeyboardButton("\u274c Cancel", callback_data="m")]])
