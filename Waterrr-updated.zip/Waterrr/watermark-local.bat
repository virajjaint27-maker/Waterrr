@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Local Watermark Processor

if "%~1"=="" (
    echo Usage:
    echo   watermark-local.bat "D:\Media\input.mp4" "D:\Media\watermarked.mp4" --text "@YourBrand"
    echo.
    echo Optional: --color #FFFFFF --size 5 --opacity 70 --position bottom_right --animation none
    echo For a logo file, add: --logo "D:\Media\logo.png"
    echo The local output stays on this server; it is not uploaded to Telegram.
    pause
    exit /b 2
)

set "PY_LAUNCHER="
where py >nul 2>nul
if not errorlevel 1 (
    py -3 --version >nul 2>nul
    if not errorlevel 1 set "PY_LAUNCHER=py -3"
)
if not defined PY_LAUNCHER (
    where python >nul 2>nul
    if errorlevel 1 goto no_python
    set "PY_LAUNCHER=python"
)

%PY_LAUNCHER% -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
if errorlevel 1 goto old_python

if not exist ".venv\Scripts\python.exe" (
    echo Creating the Python environment...
    %PY_LAUNCHER% -m venv .venv
    if errorlevel 1 goto setup_failed
)

set "BOT_PY=%CD%\.venv\Scripts\python.exe"
"%BOT_PY%" -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
if errorlevel 1 goto old_python

echo Installing/checking local Python dependencies...
"%BOT_PY%" -m pip install --disable-pip-version-check -r requirements-local.txt
if errorlevel 1 goto setup_failed

"%BOT_PY%" -m telegram_bot.local_watermark %*
set "EXIT_CODE=%ERRORLEVEL%"
if not "%EXIT_CODE%"=="0" echo Watermark command exited with code %EXIT_CODE%.
pause
exit /b %EXIT_CODE%

:no_python
echo ERROR: Python 3.10 or newer was not found. Install 64-bit Python and enable Add Python to PATH.
pause
exit /b 1

:old_python
echo ERROR: Python 3.10 or newer is required. Install a 64-bit version and rerun this tool.
pause
exit /b 1

:setup_failed
echo ERROR: Setup failed. Check internet access, Python installation, and requirements-local.txt.
pause
exit /b 1
