@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Watermark Telegram Bot

if not exist ".env" (
    if exist ".env.example" (
        copy /Y ".env.example" ".env" >nul
        echo Created .env from .env.example.
        echo Edit .env with your Telegram credentials and DATABASE_URL, then run start.bat again.
    ) else (
        echo ERROR: .env is missing and .env.example was not found.
    )
    pause
    exit /b 1
)

set "PY_LAUNCHER="
where py >nul 2>nul
if not errorlevel 1 (
    py -3 --version >nul 2>nul
    if not errorlevel 1 set "PY_LAUNCHER=py -3"
)
if not defined PY_LAUNCHER (
    where python >nul 2>nul
    if errorlevel 1 goto no_python
    set "PY_LAUNCHER=python"
)

if not exist ".venv\Scripts\python.exe" (
    echo Creating the virtual environment...
    %PY_LAUNCHER% -m venv .venv
    if errorlevel 1 goto setup_failed
)

set "BOT_PY=%CD%\.venv\Scripts\python.exe"
"%BOT_PY%" -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)"
if errorlevel 1 goto old_python

echo Installing/checking Python dependencies...
"%BOT_PY%" -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 goto setup_failed

where ffmpeg.exe >nul 2>nul
if errorlevel 1 goto no_ffmpeg
where ffprobe.exe >nul 2>nul
if errorlevel 1 goto no_ffprobe

echo.
echo Starting the Watermark Telegram Bot...
echo Keep this window open while the bot runs. Press Ctrl+C to stop it.
echo If startup reports a PostgreSQL connection error, fix DATABASE_URL in .env.
echo.
"%BOT_PY%" -m telegram_bot.main
set "BOT_EXIT_CODE=%ERRORLEVEL%"
if not "%BOT_EXIT_CODE%"=="0" echo Bot exited with code %BOT_EXIT_CODE%.
pause
exit /b %BOT_EXIT_CODE%

:no_python
echo ERROR: Python 3.10 or newer was not found. Install 64-bit Python and enable Add Python to PATH.
pause
exit /b 1

:old_python
echo ERROR: Python 3.10 or newer is required.
pause
exit /b 1

:no_ffmpeg
echo ERROR: ffmpeg.exe was not found on PATH. Install a 64-bit FFmpeg build and add its bin folder to PATH.
pause
exit /b 1

:no_ffprobe
echo ERROR: ffprobe.exe was not found on PATH. It is normally included in the FFmpeg bin folder.
pause
exit /b 1

:setup_failed
echo ERROR: Bot setup failed. Check the messages above, internet access, and requirements.txt.
pause
exit /b 1
