"""Apply a watermark to a file already stored on this machine, bypassing Telegram transfer limits."""
from __future__ import annotations

import argparse
import asyncio
from pathlib import Path

from telegram_bot.constants import (
    ANIMATIONS,
    DEFAULT_SETTINGS,
    FONTS,
    POSITIONS,
    SUPPORTED_IMAGE_EXT,
    SUPPORTED_VIDEO_EXT,
)
from telegram_bot.utils.ffmpeg_utils import ensure_ffmpeg_available
from telegram_bot.utils.progress import human_size
from telegram_bot.watermark.image_watermark import apply_image_watermark
from telegram_bot.watermark.video_watermark import apply_video_watermark


class ConsoleProgress:
    """Small progress adapter for FFmpeg's asynchronous progress callback."""

    def __init__(self) -> None:
        self._last_percent = -1

    async def update(self, current: int, total: int) -> None:
        percent = (current / total * 100) if total else 0.0
        if percent >= 100 or percent - self._last_percent >= 1:
            self._last_percent = int(percent)
            print(
                f"\rWatermarking video: {percent:5.1f}%",
                end="",
                flush=True,
            )


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Watermark a local file already on the RDP server. This avoids Telegram's "
            "per-file upload/download ceiling; the output is saved locally."
        )
    )
    parser.add_argument("input", type=Path, help="path to the source media on this server")
    parser.add_argument("output", type=Path, help="path for the watermarked output")
    parser.add_argument("--text", default=DEFAULT_SETTINGS["text"], help="watermark text")
    parser.add_argument("--color", default=DEFAULT_SETTINGS["color"], help="text color, e.g. #FFFFFF")
    parser.add_argument("--font", choices=tuple(FONTS), default=DEFAULT_SETTINGS["font"])
    parser.add_argument("--size", type=int, default=DEFAULT_SETTINGS["size"], help="size percentage (1-40)")
    parser.add_argument("--opacity", type=int, default=DEFAULT_SETTINGS["opacity"], help="opacity (1-100)")
    parser.add_argument("--position", choices=tuple(POSITIONS), default=DEFAULT_SETTINGS["position"])
    parser.add_argument("--animation", choices=tuple(ANIMATIONS), default=DEFAULT_SETTINGS["animation"])
    parser.add_argument("--logo", type=Path, help="optional image file to use instead of text")
    return parser


async def _process_video(input_path: Path, output_path: Path, settings: dict, logo_path: Path | None) -> None:
    ensure_ffmpeg_available()
    tracker = ConsoleProgress()
    await apply_video_watermark(
        str(input_path),
        str(output_path),
        settings,
        logo_path=str(logo_path) if logo_path else None,
        tracker=tracker,
    )
    print()


def main() -> int:
    parser = _parser()
    args = parser.parse_args()

    input_path = args.input.expanduser().resolve()
    output_path = args.output.expanduser().resolve()
    logo_path = args.logo.expanduser().resolve() if args.logo else None

    if not input_path.is_file():
        parser.error(f"Input file does not exist: {input_path}")
    if input_path == output_path:
        parser.error("Input and output paths must be different.")
    if logo_path is not None and not logo_path.is_file():
        parser.error(f"Logo file does not exist: {logo_path}")
    if not (1 <= args.size <= 40):
        parser.error("--size must be between 1 and 40.")
    if not (1 <= args.opacity <= 100):
        parser.error("--opacity must be between 1 and 100.")

    extension = input_path.suffix.lower()
    video_extensions = SUPPORTED_VIDEO_EXT | {".gif"}
    if extension not in SUPPORTED_IMAGE_EXT and extension not in video_extensions:
        parser.error(f"Unsupported input extension: {extension or '(none)'}")

    is_video = extension in video_extensions
    output_extension = output_path.suffix.lower()
    if is_video and output_extension != ".mp4":
        parser.error("For video output, use an .mp4 filename (for example, watermarked.mp4).")
    if not is_video and output_extension not in {".jpg", ".jpeg", ".png", ".webp"}:
        parser.error("For image output, use a .jpg, .jpeg, .png, or .webp filename.")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    settings = dict(DEFAULT_SETTINGS)
    settings.update(
        text=args.text,
        color=args.color,
        font=args.font,
        size=args.size,
        opacity=args.opacity,
        position=args.position,
        animation=args.animation,
        mode="image" if logo_path else "text",
    )

    try:
        if is_video:
            asyncio.run(_process_video(input_path, output_path, settings, logo_path))
        else:
            print("Applying image watermark. Very large images need substantial RAM...")
            apply_image_watermark(
                str(input_path),
                str(output_path),
                settings,
                logo_path=str(logo_path) if logo_path else None,
            )
    except KeyboardInterrupt:
        print("\nCancelled.")
        return 130
    except Exception as exc:  # noqa: BLE001 - CLI reports a short local error
        print(f"Watermarking failed: {exc}")
        return 1

    print(f"Done: {output_path}")
    print(f"Output size: {human_size(output_path.stat().st_size)}")
    print("The output remains on this server; this local tool does not upload it to Telegram.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
