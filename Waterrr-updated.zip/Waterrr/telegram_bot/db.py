"""
Postgres persistence layer for per-user watermark settings.

Uses asyncpg directly against the same DATABASE_URL the Next.js app uses.
Settings are stored as a single JSONB blob per user so new settings fields
can be added later without writing migrations.
"""
from __future__ import annotations

import json
from copy import deepcopy
from typing import Any, Optional

import asyncpg

from telegram_bot.config import DATABASE_URL
from telegram_bot.constants import DEFAULT_SETTINGS

_pool: Optional[asyncpg.Pool] = None

CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS telegram_watermark_settings (
    user_id BIGINT PRIMARY KEY,
    settings JSONB NOT NULL DEFAULT '{}'::jsonb,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS telegram_watermark_stats (
    user_id BIGINT PRIMARY KEY,
    files_processed INTEGER NOT NULL DEFAULT 0,
    bytes_processed BIGINT NOT NULL DEFAULT 0,
    last_used_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
"""


async def init_db() -> None:
    """Create the asyncpg connection pool and ensure tables exist."""
    global _pool
    _pool = await asyncpg.create_pool(dsn=DATABASE_URL, min_size=1, max_size=10)
    async with _pool.acquire() as conn:
        await conn.execute(CREATE_TABLE_SQL)


async def close_db() -> None:
    global _pool
    if _pool is not None:
        await _pool.close()
        _pool = None


def _merge_defaults(stored: dict[str, Any]) -> dict[str, Any]:
    merged = deepcopy(DEFAULT_SETTINGS)
    merged.update(stored or {})
    return merged


async def get_settings(user_id: int) -> dict[str, Any]:
    assert _pool is not None, "db not initialized"
    async with _pool.acquire() as conn:
        row = await conn.fetchrow(
            "SELECT settings FROM telegram_watermark_settings WHERE user_id = $1",
            user_id,
        )
        if row is None:
            defaults = deepcopy(DEFAULT_SETTINGS)
            await conn.execute(
                """
                INSERT INTO telegram_watermark_settings (user_id, settings)
                VALUES ($1, $2::jsonb)
                ON CONFLICT (user_id) DO NOTHING
                """,
                user_id,
                json.dumps(defaults),
            )
            return defaults
        raw = row["settings"]
        stored = json.loads(raw) if isinstance(raw, str) else raw
        return _merge_defaults(stored)


async def update_settings(user_id: int, **changes: Any) -> dict[str, Any]:
    assert _pool is not None, "db not initialized"
    current = await get_settings(user_id)
    current.update(changes)
    async with _pool.acquire() as conn:
        await conn.execute(
            """
            INSERT INTO telegram_watermark_settings (user_id, settings, updated_at)
            VALUES ($1, $2::jsonb, now())
            ON CONFLICT (user_id)
            DO UPDATE SET settings = $2::jsonb, updated_at = now()
            """,
            user_id,
            json.dumps(current),
        )
    return current


async def reset_settings(user_id: int) -> dict[str, Any]:
    defaults = deepcopy(DEFAULT_SETTINGS)
    async with _pool.acquire() as conn:
        await conn.execute(
            """
            INSERT INTO telegram_watermark_settings (user_id, settings, updated_at)
            VALUES ($1, $2::jsonb, now())
            ON CONFLICT (user_id)
            DO UPDATE SET settings = $2::jsonb, updated_at = now()
            """,
            user_id,
            json.dumps(defaults),
        )
    return defaults


async def record_usage(user_id: int, file_size: int) -> None:
    assert _pool is not None, "db not initialized"
    async with _pool.acquire() as conn:
        await conn.execute(
            """
            INSERT INTO telegram_watermark_stats (user_id, files_processed, bytes_processed, last_used_at)
            VALUES ($1, 1, $2, now())
            ON CONFLICT (user_id)
            DO UPDATE SET
                files_processed = telegram_watermark_stats.files_processed + 1,
                bytes_processed = telegram_watermark_stats.bytes_processed + EXCLUDED.bytes_processed,
                last_used_at = now()
            """,
            user_id,
            file_size,
        )


async def global_stats() -> dict[str, Any]:
    assert _pool is not None, "db not initialized"
    async with _pool.acquire() as conn:
        row = await conn.fetchrow(
            """
            SELECT
                COUNT(*) AS users,
                COALESCE(SUM(files_processed), 0) AS files_processed,
                COALESCE(SUM(bytes_processed), 0) AS bytes_processed
            FROM telegram_watermark_stats
            """
        )
        return dict(row)
