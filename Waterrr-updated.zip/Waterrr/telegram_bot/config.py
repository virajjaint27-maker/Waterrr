"""
Central configuration for the Watermark Telegram Bot.

All runtime configuration is read from environment variables (loaded from the
project's root `.env` file). Nothing here contains secrets - fill the real
values inside `.env` before starting the bot.
"""
from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

# telegram_bot/ directory
BASE_DIR = Path(__file__).resolve().parent
ASSETS_DIR = BASE_DIR / "assets"
# project root (one level up, where the shared .env file lives)
PROJECT_ROOT = BASE_DIR.parent
ENV_PATH = PROJECT_ROOT / ".env"

# Load the project .env (shared with the rest of the repo) as well as any
# local .env placed next to this file, local one wins.
load_dotenv(dotenv_path=ENV_PATH, override=False)
load_dotenv(dotenv_path=BASE_DIR / ".env", override=True)


def _get_int(name: str, default: int | None = None) -> int:
    raw = os.environ.get(name)
    if raw is None or raw.strip() == "" or raw.strip().startswith("your_"):
        if default is not None:
            return default
        raise RuntimeError(
            f"Missing required environment variable '{name}'. "
            f"Add it to {ENV_PATH}"
        )
    return int(raw)


def _get_str(name: str, default: str | None = None, required: bool = True) -> str:
    raw = os.environ.get(name, default)
    if required and (raw is None or raw.strip() == "" or raw.startswith("your_")):
        raise RuntimeError(
            f"Missing required environment variable '{name}'. "
            f"Add a real value to {ENV_PATH}"
        )
    return raw or ""


# ---------------------------------------------------------------------------
# Telegram credentials - get API_ID / API_HASH from https://my.telegram.org
# and BOT_TOKEN from @BotFather
# ---------------------------------------------------------------------------
API_ID = _get_int("API_ID", default=0)
API_HASH = _get_str("API_HASH", default="", required=False)
BOT_TOKEN = _get_str("BOT_TOKEN", default="", required=False)

# Optional: comma separated list of Telegram user IDs allowed to use /stats
ADMIN_IDS = {
    int(x) for x in os.environ.get("ADMIN_IDS", "").split(",") if x.strip().isdigit()
}

# Optional Telegram channel used for the force-join membership gate.
# User media is not forwarded to this channel.
CHANNEL_ID = os.environ.get("CHANNEL_ID", "").strip()
CHANNEL_URL = os.environ.get("CHANNEL_URL", "").strip()
if not CHANNEL_URL and CHANNEL_ID.startswith("@"):
    CHANNEL_URL = f"https://t.me/{CHANNEL_ID[1:]}"

# Database (re-uses the same Postgres instance as the Next.js app)
DATABASE_URL = os.environ.get(
    "DATABASE_URL", "postgresql://postgres:postgres@127.0.0.1:5432/app_db"
)

# Local working directories
DOWNLOADS_DIR = BASE_DIR / "downloads"
OUTPUTS_DIR = BASE_DIR / "outputs"
FONTS_DIR = BASE_DIR / "fonts"
DOWNLOADS_DIR.mkdir(parents=True, exist_ok=True)
OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)

# Pyrogram session name / workdir
SESSION_NAME = os.environ.get("BOT_SESSION_NAME", "watermark_bot")

# Performance tuning for large files near the MTProto transfer ceiling
WORKERS = _get_int("BOT_WORKERS", default=8)
MAX_CONCURRENT_TRANSMISSIONS = _get_int("BOT_MAX_CONCURRENT_TRANSMISSIONS", default=4)

# ffmpeg / ffprobe binaries (override if not on PATH)
FFMPEG_BIN = os.environ.get("FFMPEG_BIN", "ffmpeg")
FFPROBE_BIN = os.environ.get("FFPROBE_BIN", "ffprobe")

# Pyrogram documents MTProto bot transfers up to 2000 MiB per file. Keep the
# local guard aligned with that ceiling; files above it need a different input
# route or a separately implemented user-session workflow.
MAX_FILE_SIZE_BYTES = _get_int("MAX_FILE_SIZE_MB", default=2000) * 1024 * 1024
