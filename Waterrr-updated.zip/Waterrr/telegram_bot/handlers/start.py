from __future__ import annotations

import logging

from pyrogram import filters
from pyrogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from telegram_bot.bot import PENDING_INPUT, app
from telegram_bot.config import ADMIN_IDS, ASSETS_DIR
from telegram_bot.db import global_stats
from telegram_bot.utils.membership import (
    check_channel_membership,
    join_keyboard,
    join_prompt,
    require_channel_membership,
)
from telegram_bot.utils.stickers import (
    next_random_item,
    reply_with_error,
    send_random_sticker,
)
from telegram_bot.utils.text_style import monospace_text

log = logging.getLogger(__name__)

WELCOME_IMAGES = (
    str(ASSETS_DIR / "watermark-welcome-1.png"),
    str(ASSETS_DIR / "watermark-welcome-2.png"),
)

WELCOME_TEXT = monospace_text(
    "\U0001f4a7 *Watermark Bot*\n\n"
    "Send me *any photo, video, GIF or document* and I will stamp it with your "
    "custom watermark - text or logo, any color, any font, any position, even "
    "animated like a bouncing DVD logo.\n\n"
    "Works with large files up to about 2000 MiB, depending on Telegram limits.\n\n"
    "\u2699\ufe0f Use /settings to customize everything before you send media.\n"
    "\u2753 Use /help to see all commands."
)

HELP_TEXT = monospace_text(
    "*Commands*\n\n"
    "/settings - open the watermark settings panel\n"
    "/cancel - cancel whatever input I'm currently waiting for\n"
    "/help - show this message\n\n"
    "*How it works*\n"
    "1. Configure your watermark with /settings (text or logo image, color, "
    "font, size, opacity, position and animation).\n"
    "2. Send me a photo, video, GIF or video/image document.\n"
    "3. I download it, stamp the watermark on it (with a live progress bar) "
    "and send it back.\n\n"
    "*Animations*\n"
    "\U0001f4c0 DVD Bounce - the watermark bounces around the frame and reflects "
    "off every edge, exactly like the classic DVD screensaver.\n"
    "\u27a1\ufe0f Slide In - the watermark slides in from off-screen and settles in place.\n"
    "\U0001f32b Fade In - the watermark fades in from transparent to its target opacity.\n"
    "(Animations apply to videos/GIFs; photos always use a static position.)"
)


def _welcome_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [[
            InlineKeyboardButton(monospace_text("\u2699\ufe0f Settings"), callback_data="m"),
            InlineKeyboardButton(monospace_text("\u2753 Help"), callback_data="help"),
        ]]
    )


@app.on_message(filters.command("start") & filters.private)
async def start_cmd(client, message: Message):
    user_id = message.from_user.id

    # Keep stickers as Telegram stickers (not custom/premium emoji), and rotate
    # through the pack so consecutive /start commands get different stickers.
    await send_random_sticker(
        client,
        message.chat.id,
        "start",
        user_id=user_id,
        reply_to_message_id=message.id,
    )

    member_status = await check_channel_membership(client, user_id)
    caption = WELCOME_TEXT if member_status is True else join_prompt(member_status)
    keyboard = _welcome_keyboard() if member_status is True else join_keyboard()
    image = next_random_item(WELCOME_IMAGES, category="welcome-image", user_id=user_id)
    try:
        await client.send_photo(
            chat_id=message.chat.id,
            photo=image,
            caption=caption,
            reply_markup=keyboard,
            reply_to_message_id=message.id,
        )
    except Exception:  # noqa: BLE001 - keep /start usable if an asset upload fails
        log.exception("Could not send the welcome image")
        await message.reply_text(caption, reply_markup=keyboard)


@app.on_callback_query(filters.regex(r"^join:check$"))
async def join_check_callback(client, cq: CallbackQuery):
    member_status = await check_channel_membership(client, cq.from_user.id)
    if member_status is True:
        if cq.message.photo:
            await cq.message.edit_caption(WELCOME_TEXT, reply_markup=_welcome_keyboard())
        else:
            await cq.message.edit_text(WELCOME_TEXT, reply_markup=_welcome_keyboard())
        await cq.answer(monospace_text("Membership verified"))
    elif member_status is False:
        await cq.answer(
            monospace_text("Please join the channel first, then tap the check button."),
            show_alert=True,
        )
    else:
        await cq.answer(
            monospace_text("I couldn't verify membership. Please try again shortly."),
            show_alert=True,
        )


@app.on_message(filters.command("help") & filters.private)
async def help_cmd(client, message: Message):
    if not await require_channel_membership(client, message):
        return
    await message.reply_text(HELP_TEXT)


@app.on_message(filters.command("cancel") & filters.private)
async def cancel_cmd(client, message: Message):
    PENDING_INPUT.pop(message.from_user.id, None)
    await message.reply_text(
        monospace_text("\u2705 Cancelled. Send /settings to continue configuring your watermark.")
    )


@app.on_message(filters.command("stats") & filters.private)
async def stats_cmd(client, message: Message):
    if not await require_channel_membership(client, message):
        return
    if ADMIN_IDS and message.from_user.id not in ADMIN_IDS:
        await reply_with_error(client, message, "\u26d4 You are not authorized to use this command.")
        return
    stats = await global_stats()
    await message.reply_text(
        monospace_text(
            "\U0001f4ca *Bot stats*\n\n"
            f"Users: `{stats.get('users', 0)}`\n"
            f"Files processed: `{stats.get('files_processed', 0)}`\n"
            f"Bytes processed: `{stats.get('bytes_processed', 0)}`"
        )
    )
