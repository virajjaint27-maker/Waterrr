"""Static choices shown in the /settings menu."""

# key -> (display name, font filename inside telegram_bot/fonts/)
FONTS = {
    "poppins_bold": ("Poppins Bold", "Poppins-Bold.ttf"),
    "poppins_regular": ("Poppins Regular", "Poppins-Regular.ttf"),
    "opensans": ("Open Sans", "OpenSans-Regular.ttf"),
    "oswald": ("Oswald", "Oswald-Regular.ttf"),
    "anton": ("Anton (Bold Display)", "Anton-Regular.ttf"),
    "bebas": ("Bebas Neue", "BebasNeue-Regular.ttf"),
    "pacifico": ("Pacifico (Script)", "Pacifico-Regular.ttf"),
    "lobster": ("Lobster (Script)", "Lobster-Regular.ttf"),
    "dancing": ("Dancing Script", "DancingScript-Regular.ttf"),
    "courier": ("Courier Stamp", "CourierPrime-Bold.ttf"),
}

# key -> hex color
COLORS = {
    "white": "#FFFFFF",
    "black": "#000000",
    "red": "#FF3B30",
    "orange": "#FF9500",
    "yellow": "#FFCC00",
    "green": "#34C759",
    "teal": "#30B0C7",
    "blue": "#007AFF",
    "purple": "#AF52DE",
    "pink": "#FF2D55",
}

# key -> label
POSITIONS = {
    "top_left": "\u2196\ufe0f Top Left",
    "top_right": "\u2197\ufe0f Top Right",
    "bottom_left": "\u2199\ufe0f Bottom Left",
    "bottom_right": "\u2198\ufe0f Bottom Right",
    "center": "\u23fa Center",
    "random": "\U0001f3b2 Random",
}

STATIC_POSITIONS = [
    "top_left",
    "top_right",
    "bottom_left",
    "bottom_right",
    "center",
]

# key -> label
ANIMATIONS = {
    "none": "\U0001f6ab None (Static)",
    "dvd_bounce": "\U0001f4c0 DVD Bounce",
    "slide": "\u27a1\ufe0f Slide In",
    "fade": "\U0001f32b Fade In",
}

SIZE_PRESETS = [3, 5, 8, 12, 16]
OPACITY_PRESETS = [30, 50, 70, 90, 100]

DEFAULT_SETTINGS = {
    "mode": "text",  # "text" or "image" (logo)
    "text": "@YourBrand",
    "color": "#FFFFFF",
    "font": "poppins_bold",
    "size": 5,  # percent of the shorter media dimension
    "opacity": 70,  # percent
    "position": "bottom_right",
    "animation": "none",
    "logo_file_id": None,
}

SUPPORTED_IMAGE_EXT = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}
SUPPORTED_VIDEO_EXT = {".mp4", ".mkv", ".mov", ".avi", ".webm", ".m4v", ".3gp"}
