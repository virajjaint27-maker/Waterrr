"""Applies a text or logo watermark to a static image using Pillow."""
from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

from PIL import Image, ImageDraw, ImageFont

from telegram_bot.utils.fonts import resolve_font_path
from telegram_bot.utils.position import compute_static_xy, hex_to_rgb


def _load_font(font_key: str, size: int) -> ImageFont.FreeTypeFont:
    path = resolve_font_path(font_key)
    return ImageFont.truetype(str(path), size)


def apply_image_watermark(
    input_path: str,
    output_path: str,
    settings: dict[str, Any],
    logo_path: Optional[str] = None,
) -> None:
    with Image.open(input_path) as src:
        base = src.convert("RGBA")

    width, height = base.size
    layer = Image.new("RGBA", base.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(layer)
    opacity = max(0, min(100, int(settings.get("opacity", 70))))
    alpha = int(255 * opacity / 100)

    if settings.get("mode") == "image" and logo_path:
        with Image.open(logo_path) as logo_src:
            logo = logo_src.convert("RGBA")
        target_w = max(16, int(width * (settings.get("size", 5) * 3) / 100))
        ratio = target_w / logo.width
        target_h = max(16, int(logo.height * ratio))
        logo = logo.resize((target_w, target_h), Image.LANCZOS)
        r, g, b, a = logo.split()
        a = a.point(lambda p: int(p * alpha / 255))
        logo = Image.merge("RGBA", (r, g, b, a))
        x, y = compute_static_xy(settings.get("position", "bottom_right"), width, height, logo.width, logo.height)
        layer.paste(logo, (x, y), logo)
    else:
        text = (settings.get("text") or "@YourBrand").strip() or "@YourBrand"
        font_size = max(12, int(min(width, height) * settings.get("size", 5) / 100))
        font = _load_font(settings.get("font", "poppins_bold"), font_size)
        bbox = draw.textbbox((0, 0), text, font=font)
        box_w, box_h = bbox[2] - bbox[0], bbox[3] - bbox[1]
        x, y = compute_static_xy(settings.get("position", "bottom_right"), width, height, box_w, box_h)
        color = hex_to_rgb(settings.get("color", "#FFFFFF")) + (alpha,)
        # Subtle shadow for readability on any background.
        shadow_color = (0, 0, 0, int(alpha * 0.55))
        draw.text((x - bbox[0] + 2, y - bbox[1] + 2), text, font=font, fill=shadow_color)
        draw.text((x - bbox[0], y - bbox[1]), text, font=font, fill=color)

    composite = Image.alpha_composite(base, layer)

    save_kwargs: dict[str, Any] = {}
    out_ext = Path(output_path).suffix.lower()
    if out_ext in (".jpg", ".jpeg"):
        composite = composite.convert("RGB")
        save_kwargs["quality"] = 95
        composite.save(output_path, format="JPEG", **save_kwargs)
    elif out_ext == ".webp":
        composite.save(output_path, format="WEBP", quality=95)
    else:
        composite.save(output_path, format="PNG")
