"""Human readable summaries of the current settings, shown above the menu."""
from __future__ import annotations

from typing import Any

from telegram_bot.constants import ANIMATIONS, FONTS, POSITIONS
from telegram_bot.utils.text_style import monospace_text


def settings_summary(settings: dict[str, Any]) -> str:
    mode = settings.get("mode", "text")
    font_label = FONTS.get(settings.get("font", "poppins_bold"), FONTS["poppins_bold"])[0]
    pos_label = POSITIONS.get(settings.get("position", "bottom_right"), "Bottom Right")
    anim_label = ANIMATIONS.get(settings.get("animation", "none"), "None")

    lines = [
        "\u2699\ufe0f *Watermark Settings*",
        "",
        f"Mode: `{ 'Text' if mode == 'text' else 'Logo Image' }`",
    ]
    if mode == "text":
        lines.append(f"Text: `{settings.get('text', '')}`")
        lines.append(f"Font: `{font_label}`")
        lines.append(f"Color: `{settings.get('color', '#FFFFFF')}`")
    else:
        has_logo = bool(settings.get("logo_file_id"))
        lines.append(f"Logo uploaded: `{'Yes' if has_logo else 'No - tap below to upload'}`")
    lines.extend(
        [
            f"Size: `{settings.get('size', 5)}%`",
            f"Opacity: `{settings.get('opacity', 70)}%`",
            f"Position: `{pos_label}`",
            f"Animation: `{anim_label}`",
            "",
            "Tap a button below to change a setting. Then just send any photo, "
            "video, GIF or document and the watermark will be applied automatically "
            "- for files up to the configured Telegram transfer limit.",
        ]
    )
    return monospace_text("\n".join(lines))
