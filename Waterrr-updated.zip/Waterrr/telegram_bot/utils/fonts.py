"""Resolve a requested watermark font, falling back to a system font."""
from __future__ import annotations

import os
from pathlib import Path

from telegram_bot.config import FONTS_DIR
from telegram_bot.constants import FONTS


def resolve_font_path(font_key: str) -> Path:
    """Use the bundled font when available, otherwise fall back to system Arial."""
    filename = FONTS.get(font_key, FONTS["poppins_bold"])[1]
    bundled = FONTS_DIR / filename
    if bundled.is_file():
        return bundled

    bold = font_key in {"poppins_bold", "anton", "courier"} or "bold" in filename.lower()
    candidates: list[Path] = []

    windows_root = os.environ.get("WINDIR") or os.environ.get("SystemRoot")
    if windows_root:
        windows_fonts = Path(windows_root) / "Fonts"
        candidates.extend(
            windows_fonts / name
            for name in (("arialbd.ttf", "arial.ttf") if bold else ("arial.ttf", "arialbd.ttf"))
        )

    if bold:
        candidates.extend(
            [
                Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
                Path("/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf"),
                Path("/System/Library/Fonts/Supplemental/Arial Bold.ttf"),
            ]
        )
    else:
        candidates.extend(
            [
                Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
                Path("/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf"),
                Path("/System/Library/Fonts/Supplemental/Arial.ttf"),
            ]
        )

    for candidate in candidates:
        if candidate.is_file():
            return candidate

    raise FileNotFoundError(
        f"Font '{filename}' is missing from {FONTS_DIR}, and no system fallback font was found."
    )
