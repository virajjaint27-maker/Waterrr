"""Inline keyboard builders for the /settings menu tree."""
from __future__ import annotations

from typing import Any

from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from telegram_bot.constants import ANIMATIONS, COLORS, FONTS, OPACITY_PRESETS, POSITIONS, SIZE_PRESETS
from telegram_bot.utils.text_style import monospace_text


def _mark(label: str, selected: bool) -> str:
    return f"\u2705 {label}" if selected else label


def _button(label: str, callback_data: str) -> InlineKeyboardButton:
    return InlineKeyboardButton(monospace_text(label), callback_data=callback_data)


def main_menu_keyboard(settings: dict[str, Any]) -> InlineKeyboardMarkup:
    mode = settings.get("mode", "text")
    rows = [
        [
            _button(_mark("\U0001f170\ufe0f Text Mode", mode == "text"), "mode:text"),
            _button(_mark("\U0001f5bc\ufe0f Logo Mode", mode == "image"), "mode:image"),
        ],
    ]
    if mode == "text":
        rows.append(
            [_button(f"\u270f\ufe0f Text: {settings.get('text', '')[:20]}", "text:ask")]
        )
        rows.append(
            [
                _button("\U0001f524 Font", "font:menu"),
                _button("\U0001f3a8 Color", "color:menu"),
            ]
        )
    else:
        rows.append([_button("\U0001f5bc\ufe0f Upload Logo Image", "logo:ask")])

    rows.append(
        [
            _button("\U0001f4cf Size", "size:menu"),
            _button("\U0001f4a7 Opacity", "opacity:menu"),
        ]
    )
    rows.append(
        [
            _button("\U0001f4cd Position", "pos:menu"),
            _button("\U0001f3ac Animation", "anim:menu"),
        ]
    )
    rows.append(
        [
            _button("\U0001f504 Reset Defaults", "reset"),
            _button("\u2714\ufe0f Done", "close"),
        ]
    )
    return InlineKeyboardMarkup(rows)


def back_row(target: str = "m") -> list[InlineKeyboardButton]:
    return [_button("\u2b05\ufe0f Back", target)]


def position_keyboard(settings: dict[str, Any]) -> InlineKeyboardMarkup:
    current = settings.get("position")
    rows = []
    items = list(POSITIONS.items())
    for i in range(0, len(items), 2):
        row = []
        for key, label in items[i : i + 2]:
            row.append(_button(_mark(label, current == key), f"pos:{key}"))
        rows.append(row)
    rows.append(back_row())
    return InlineKeyboardMarkup(rows)


def animation_keyboard(settings: dict[str, Any]) -> InlineKeyboardMarkup:
    current = settings.get("animation")
    rows = []
    for key, label in ANIMATIONS.items():
        rows.append([_button(_mark(label, current == key), f"anim:{key}")])
    rows.append(back_row())
    return InlineKeyboardMarkup(rows)


def font_keyboard(settings: dict[str, Any]) -> InlineKeyboardMarkup:
    current = settings.get("font")
    rows = []
    items = list(FONTS.items())
    for i in range(0, len(items), 2):
        row = []
        for key, (label, _file) in items[i : i + 2]:
            row.append(_button(_mark(label, current == key), f"font:{key}"))
        rows.append(row)
    rows.append(back_row())
    return InlineKeyboardMarkup(rows)


def color_keyboard(settings: dict[str, Any]) -> InlineKeyboardMarkup:
    current = (settings.get("color") or "").upper()
    rows = []
    items = list(COLORS.items())
    for i in range(0, len(items), 2):
        row = []
        for key, hexval in items[i : i + 2]:
            selected = current == hexval.upper()
            row.append(_button(_mark(f"\u25cf {key.title()}", selected), f"color:{key}"))
        rows.append(row)
    rows.append([_button("\U0001f3a8 Custom HEX", "color:custom")])
    rows.append(back_row())
    return InlineKeyboardMarkup(rows)


def size_keyboard(settings: dict[str, Any]) -> InlineKeyboardMarkup:
    current = settings.get("size")
    rows = [[]]
    for preset in SIZE_PRESETS:
        rows[0].append(_button(_mark(f"{preset}%", current == preset), f"size:{preset}"))
    rows.append([_button("\u2699\ufe0f Custom", "size:custom")])
    rows.append(back_row())
    return InlineKeyboardMarkup(rows)


def opacity_keyboard(settings: dict[str, Any]) -> InlineKeyboardMarkup:
    current = settings.get("opacity")
    rows = [[]]
    for preset in OPACITY_PRESETS:
        rows[0].append(_button(_mark(f"{preset}%", current == preset), f"opacity:{preset}"))
    rows.append([_button("\u2699\ufe0f Custom", "opacity:custom")])
    rows.append(back_row())
    return InlineKeyboardMarkup(rows)


def cancel_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[_button("\u274c Cancel", "m")]])
