"""Shared positioning / animation math for both the Pillow (image) and
ffmpeg (video) watermark renderers.

The DVD-bounce animation uses the classic stateless ffmpeg trick: the
position is expressed purely as a function of time `t` using `mod()` and
`abs()`, which produces a perfect triangle wave that reflects off every
edge of the frame - exactly like the DVD logo screensaver.
"""
from __future__ import annotations

import random

MARGIN = 20


def hex_to_rgb(hex_color: str) -> tuple[int, int, int]:
    hex_color = hex_color.lstrip("#")
    if len(hex_color) == 3:
        hex_color = "".join(c * 2 for c in hex_color)
    return tuple(int(hex_color[i : i + 2], 16) for i in (0, 2, 4))  # type: ignore[return-value]


def hex_to_ffmpeg_color(hex_color: str) -> str:
    """ffmpeg understands 0xRRGGBB color literals."""
    return "0x" + hex_color.lstrip("#").upper()


def resolve_position(position: str) -> str:
    """Resolves the 'random' choice to one concrete static position."""
    from telegram_bot.constants import STATIC_POSITIONS

    if position == "random":
        return random.choice(STATIC_POSITIONS)
    return position


def compute_static_xy(position: str, frame_w: int, frame_h: int, box_w: int, box_h: int) -> tuple[int, int]:
    position = resolve_position(position)
    if position == "top_left":
        return MARGIN, MARGIN
    if position == "top_right":
        return frame_w - box_w - MARGIN, MARGIN
    if position == "bottom_left":
        return MARGIN, frame_h - box_h - MARGIN
    if position == "bottom_right":
        return frame_w - box_w - MARGIN, frame_h - box_h - MARGIN
    if position == "center":
        return (frame_w - box_w) // 2, (frame_h - box_h) // 2
    return frame_w - box_w - MARGIN, frame_h - box_h - MARGIN


def build_ffmpeg_xy_expr(
    position: str,
    animation: str,
    frame_w_var: str,
    frame_h_var: str,
    box_w_var: str,
    box_h_var: str,
) -> tuple[str, str]:
    """Builds ffmpeg x/y expressions for drawtext (frame_w_var='w', box_w_var='text_w')
    or overlay (frame_w_var='W', box_w_var='w')."""
    FW, FH, OW, OH = frame_w_var, frame_h_var, box_w_var, box_h_var
    position = resolve_position(position)

    static_map = {
        "top_left": (f"{MARGIN}", f"{MARGIN}"),
        "top_right": (f"{FW}-{OW}-{MARGIN}", f"{MARGIN}"),
        "bottom_left": (f"{MARGIN}", f"{FH}-{OH}-{MARGIN}"),
        "bottom_right": (f"{FW}-{OW}-{MARGIN}", f"{FH}-{OH}-{MARGIN}"),
        "center": (f"({FW}-{OW})/2", f"({FH}-{OH})/2"),
    }
    x_final, y_final = static_map.get(position, static_map["bottom_right"])

    if animation == "dvd_bounce":
        vx, vy = 140, 95
        span_x = f"max({FW}-{OW}\\,1)"
        span_y = f"max({FH}-{OH}\\,1)"
        x_expr = f"({span_x})-abs(mod(t*{vx}\\,2*({span_x}))-({span_x}))"
        y_expr = f"({span_y})-abs(mod(t*{vy}\\,2*({span_y}))-({span_y}))"
        return x_expr, y_expr

    if animation == "slide":
        # Slides in from the right edge over 1.5s, then rests at x_final.
        x_expr = f"if(lt(t\\,1.5)\\,{FW}-({FW}-({x_final}))*(t/1.5)\\,{x_final})"
        return x_expr, y_final

    # "fade" and "none" both use a static resting position; fade animates
    # opacity instead (handled separately by the caller).
    return x_final, y_final


def build_fade_alpha_expr(target_opacity_fraction: float, duration: float = 1.5) -> str:
    return f"if(lt(t\\,{duration})\\,(t/{duration})*{target_opacity_fraction}\\,{target_opacity_fraction})"


def escape_drawtext_literal(text: str) -> str:
    """Escapes characters that are special inside an inline drawtext `text=` value.
    Used only as a fallback; the renderer prefers `textfile=` to sidestep escaping."""
    return (
        text.replace("\\", "\\\\")
        .replace(":", "\\:")
        .replace("'", "\u2019")
        .replace("%", "\\%")
    )
