"""Unicode text styling that mimics the Mathematical Monospace paragraph style.

Telegram does not expose arbitrary font selection for ordinary messages. These
Unicode Mathematical Monospace characters provide the closest text-only match.
Known commands, URLs, mentions, and inline code are kept in plain ASCII so they
remain easy to copy and use.
"""
from __future__ import annotations

import re

_TRANSLATION = str.maketrans(
    {
        **{chr(ord("A") + i): chr(0x1D670 + i) for i in range(26)},
        **{chr(ord("a") + i): chr(0x1D68A + i) for i in range(26)},
        **{chr(ord("0") + i): chr(0x1D7F6 + i) for i in range(10)},
    }
)

# Don't transform Markdown code, URLs, handles, or command names. Apart from
# preserving readability, this keeps bot commands copyable in Telegram.
_PROTECTED = re.compile(
    r"```[\s\S]*?```"
    r"|`[^`\n]*`"
    r"|(?<![A-Za-z0-9_])/(?:start|settings|cancel|help|stats)(?:@[A-Za-z0-9_]+)?(?![A-Za-z0-9_])"
    r"|https?://\S+"
    r"|@[A-Za-z0-9_]{5,32}"
)


def monospace_text(text: str) -> str:
    """Convert Latin letters and digits to the Unicode style shown in the sample."""
    if not text:
        return text

    result: list[str] = []
    offset = 0
    for match in _PROTECTED.finditer(text):
        result.append(text[offset : match.start()].translate(_TRANSLATION))
        result.append(match.group())
        offset = match.end()
    result.append(text[offset:].translate(_TRANSLATION))
    return "".join(result)
