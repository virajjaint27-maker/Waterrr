"""Curated Telegram sticker packs with per-user shuffled, non-repeating cycles."""
from __future__ import annotations

import logging
import random
from collections.abc import Sequence
from typing import Literal

from pyrogram.types import Message

from telegram_bot.utils.text_style import monospace_text

StickerKind = Literal["start", "error", "complete", "processing"]

STICKER_PACKS: dict[StickerKind, tuple[str, ...]] = {
    "start": (
        "CAACAgIAAxkBAAEHaQRqwl5_jdx8Dz0sNIbxxZSBSpXeYQACfhoAAnMsOUgm5dy7Utq1lD0E",
        "CAACAgIAAxkBAAEHaRpqwmGDgSc2I8AezJ11mJ487m6KQAACMRwAAq1vuUrkxoY-S-XQFz0E",
        "CAACAgIAAxkBAAEHaRxqwmGy7iyjmk-D0QIjGMcCJJfDUQACcRwAAq1vuUr590M6JOzETT0E",
        "CAACAgIAAxkBAAEHaR5qwmInjK1-aWYoNgTDc8m24HrFcQAC0hsAAq1vuUop_Oa-SCydxD0E",
    ),
    "error": (
        "CAACAgIAAxkBAAEHaSJqwmJl5hq4lYXWFJws2DEAAddO4REAAskbAAKtb7lKK8hCwxP4z-09BA",
        "CAACAgIAAxkBAAEHaSRqwmKKO8DBbW8dLFra305oev54qQACyhsAAq1vuUr4Camg1kwbiT0E",
        "CAACAgIAAxkBAAEHaShqwmKmf34u5c5yQM4XVxjbZL6vGAACIBsAAq1vuUqs6zInoMjNoz0E",
        "CAACAgIAAxkBAAEHaSpqwmLsQ8v7mitPJ36PbJO-HW8jwAACWRsAAvVTKUnaLYrBiKXf5j0E",
        "CAACAgIAAxkBAAEHaSxqwmMMQHlwdOavb2yGXq3i6ZfT1wAC6hsAAmQ6UEmZu1sryStT-D0E",
    ),
    "complete": (
        "CAACAgIAAxkBAAEHaTNqwmNLI7bXLkNL91kbbV8vLUkwmwACdhsAAtrxKUm38vZQvuYqxD0E",
        "CAACAgIAAxkBAAEHaTZqwmNeWKP8BYuOuizBvBpQ6IaDTwAC5BcAAtlSgUmHcncYmh5Viz0E",
        "CAACAgIAAxkBAAEHaRRqwmB9T4LRsZUM7e7ouNVrvz1V1AACGxsAAr8pIElf8mnG0hX5RT0E",
        "CAACAgIAAxkBAAEHaTpqwmOKAsD4MzQSi7B_iUA89NhDiAACyxsAAgPamEiwRqVGuLHqQz0E",
        "CAACAgIAAxkBAAEHaTtqwmOKvi0vK32YyzO76U3X5Qd7KAACVRkAAj-nIEn1euu_Yd9rlj0E",
    ),
    "processing": (
        "CAACAgIAAxkBAAEHaT5qwmQcSRZ7dQS_CZuHbUK4KNoKcQACexwAAujVUElQ2GCEYrp9wT0E",
        "CAACAgIAAxkBAAEHaT9qwmQc2knHOVVG9zmbnbMPBfyzTwACtxkAAvnTMUiIbry-U_DT4j0E",
        "CAACAgIAAxkBAAEHaUBqwmQcWTgFi0RLOrCjpMynIsV7TgACQxkAAvkkmUgyn65WMo7Q1T0E",
        "CAACAgEAAxkBAAEHaUFqwmQcxcm5M103u9TiEN-KUv15lgACJQIAArC_KESLg5m2hq17Rj0E",
        "CAACAgIAAxkBAAEHaUJqwmQc-WccfqzHFJCc4r-psmTe4gACNxwAAmDyKEhgsvvzruHoWD0E",
        "CAACAgIAAxkBAAEHaUNqwmQctYXUL8pZU4pFYSM52R1BLwACeBsAArZjKElJPqq2J-v4QT0E",
    ),
}

log = logging.getLogger(__name__)
# One shuffled deck per user and purpose. This prevents the same sticker (or
# welcome image) appearing twice in a row, and uses every item before cycling.
_REMAINING: dict[tuple[str, int], list[str]] = {}
_LAST: dict[tuple[str, int], str] = {}


def next_random_item(items: Sequence[str], *, category: str, user_id: int) -> str:
    """Return a random item without repeats until a shuffled cycle is exhausted."""
    if not items:
        raise ValueError(f"No items configured for category {category!r}")

    key = (category, user_id)
    remaining = _REMAINING.get(key)
    if not remaining:
        remaining = list(items)
        random.shuffle(remaining)
        previous = _LAST.get(key)
        # Keep the new cycle from repeating the last item of the previous one.
        if len(remaining) > 1 and remaining[-1] == previous:
            remaining[0], remaining[-1] = remaining[-1], remaining[0]
        _REMAINING[key] = remaining

    selected = _REMAINING[key].pop()
    _LAST[key] = selected
    return selected


async def send_random_sticker(
    client,
    chat_id: int | str,
    kind: StickerKind,
    *,
    user_id: int,
    reply_to_message_id: int | None = None,
) -> Message | None:
    """Send one sticker from a pack; a sticker failure must not break the bot."""
    sticker_id = next_random_item(STICKER_PACKS[kind], category=f"sticker:{kind}", user_id=user_id)
    try:
        return await client.send_sticker(
            chat_id=chat_id,
            sticker=sticker_id,
            reply_to_message_id=reply_to_message_id,
        )
    except Exception:  # noqa: BLE001 - best-effort presentation, never block processing
        log.exception("Could not send a %s sticker to chat %s", kind, chat_id)
        return None


async def delete_sticker(message: Message | None) -> None:
    """Delete a temporary processing sticker, if it was successfully sent."""
    if message is None:
        return
    try:
        await message.delete()
    except Exception:  # noqa: BLE001 - best-effort cleanup
        log.warning("Could not delete the temporary processing sticker", exc_info=True)


async def reply_with_error(client, message: Message, text: str) -> Message:
    """Show an error sticker followed by the explanatory error text."""
    user = message.from_user
    await send_random_sticker(
        client,
        message.chat.id,
        "error",
        user_id=user.id if user else message.chat.id,
        reply_to_message_id=message.id,
    )
    return await message.reply_text(monospace_text(text))
