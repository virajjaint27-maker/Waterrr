"""Thin async wrappers around the ffmpeg / ffprobe CLI binaries."""
from __future__ import annotations

import asyncio
import json
import shutil
from dataclasses import dataclass
from typing import Optional

from telegram_bot.config import FFMPEG_BIN, FFPROBE_BIN
from telegram_bot.utils.progress import ProgressTracker


class FFmpegNotFoundError(RuntimeError):
    pass


def ensure_ffmpeg_available() -> None:
    if shutil.which(FFMPEG_BIN) is None or shutil.which(FFPROBE_BIN) is None:
        raise FFmpegNotFoundError(
            "ffmpeg/ffprobe were not found on PATH. Install an FFmpeg build that includes both "
            "binaries, then add its bin directory to PATH."
        )


@dataclass
class MediaInfo:
    duration: float
    width: int
    height: int
    has_audio: bool


async def probe(path: str) -> MediaInfo:
    cmd = [
        FFPROBE_BIN,
        "-v",
        "error",
        "-print_format",
        "json",
        "-show_format",
        "-show_streams",
        path,
    ]
    proc = await asyncio.create_subprocess_exec(
        *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await proc.communicate()
    if proc.returncode != 0:
        raise RuntimeError(f"ffprobe failed: {stderr.decode(errors='ignore')}")

    data = json.loads(stdout.decode(errors="ignore"))
    duration = 0.0
    try:
        duration = float(data.get("format", {}).get("duration", 0.0))
    except (TypeError, ValueError):
        duration = 0.0

    width = height = 0
    has_audio = False
    for stream in data.get("streams", []):
        if stream.get("codec_type") == "video" and not width:
            width = int(stream.get("width") or 0)
            height = int(stream.get("height") or 0)
            if not duration:
                try:
                    duration = float(stream.get("duration", 0.0))
                except (TypeError, ValueError):
                    pass
        if stream.get("codec_type") == "audio":
            has_audio = True

    return MediaInfo(duration=duration or 0.1, width=width or 1, height=height or 1, has_audio=has_audio)


async def run_ffmpeg_with_progress(
    args: list[str],
    duration: float,
    tracker: Optional[ProgressTracker] = None,
    prefix: str = "Processing",
) -> None:
    """Runs ffmpeg with machine readable progress on stdout and raises on failure."""
    cmd = [FFMPEG_BIN, "-y", *args, "-progress", "pipe:1", "-nostats", "-loglevel", "error"]
    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )

    stderr_chunks: list[bytes] = []

    async def _read_stderr():
        assert proc.stderr is not None
        while True:
            chunk = await proc.stderr.read(4096)
            if not chunk:
                break
            stderr_chunks.append(chunk)

    async def _read_stdout():
        assert proc.stdout is not None
        out_time_ms = 0
        while True:
            line = await proc.stdout.readline()
            if not line:
                break
            decoded = line.decode(errors="ignore").strip()
            if decoded.startswith("out_time_ms="):
                try:
                    out_time_ms = int(decoded.split("=", 1)[1])
                except ValueError:
                    continue
                if tracker is not None and duration > 0:
                    current_seconds = out_time_ms / 1_000_000
                    await tracker.update(
                        min(int(current_seconds * 1000), int(duration * 1000)),
                        int(duration * 1000),
                    )

    await asyncio.gather(_read_stdout(), _read_stderr())
    returncode = await proc.wait()
    if returncode != 0:
        err = b"".join(stderr_chunks).decode(errors="ignore")
        raise RuntimeError(f"ffmpeg failed ({returncode}): {err[-2000:]}")
