"""Optional force-join gate for the configured Telegram channel."""
from __future__ import annotations

import logging

from pyrogram.enums import ChatMemberStatus
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, Message

from telegram_bot.config import CHANNEL_ID, CHANNEL_URL
from telegram_bot.utils.text_style import monospace_text

log = logging.getLogger(__name__)


def join_keyboard() -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    if CHANNEL_URL:
        rows.append([InlineKeyboardButton(monospace_text("Join the channel"), url=CHANNEL_URL)])
    rows.append([InlineKeyboardButton(monospace_text("I've joined — check"), callback_data="join:check")])
    return InlineKeyboardMarkup(rows)


def join_prompt(member_status: bool | None) -> str:
    if member_status is False:
        return monospace_text(
            "Please join our channel before using the watermark bot. "
            "After joining, tap *I've joined — check* below."
        )
    return monospace_text(
        "I couldn't verify your channel membership just now. Please try again in a moment. "
        "If this keeps happening, contact the bot admin."
    )


async def check_channel_membership(client, user_id: int) -> bool | None:
    """Return True/False for membership, or None if Telegram could not verify it."""
    if not CHANNEL_ID:
        return True

    try:
        member = await client.get_chat_member(CHANNEL_ID, user_id)
    except Exception:  # noqa: BLE001 - distinguish verification failure from non-membership
        log.exception("Could not check channel membership for user %s", user_id)
        return None

    if member.status in {
        ChatMemberStatus.OWNER,
        ChatMemberStatus.ADMINISTRATOR,
        ChatMemberStatus.MEMBER,
    }:
        return True
    if member.status == ChatMemberStatus.RESTRICTED:
        return bool(getattr(member, "is_member", False))
    return False


async def require_channel_membership(
    client,
    message: Message,
    *,
    user_id: int | None = None,
) -> bool:
    """Gate a command/media message and prompt the user to join if needed."""
    if user_id is None:
        user = message.from_user
        if user is None:
            return False
        user_id = user.id

    member_status = await check_channel_membership(client, user_id)
    if member_status is True:
        return True

    await message.reply_text(join_prompt(member_status), reply_markup=join_keyboard())
    return False
