"""Entry point for the watermark Telegram bot.

Run from the project root with:

    python -m telegram_bot.main

Make sure you have filled API_ID / API_HASH / BOT_TOKEN in the project's
.env file first, installed the requirements (pip install -r requirements.txt)
and installed ffmpeg on the system (apt-get install -y ffmpeg).
"""
from __future__ import annotations

import asyncio
import logging
import shutil

from telegram_bot.bot import app
from telegram_bot.db import close_db, init_db

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
logging.getLogger("pyrogram").setLevel(logging.WARNING)
log = logging.getLogger("watermark_bot")

# Importing the handler modules registers their @app.on_message /
# @app.on_callback_query decorators onto the shared `app` Client instance.
from telegram_bot.handlers import media, settings, start, text_input  # noqa: E402,F401


async def _run() -> None:
    if shutil.which("ffmpeg") is None:
        log.warning(
            "ffmpeg was not found on PATH - video watermarking will fail until "
            "you install it (e.g. `sudo apt-get install -y ffmpeg`)."
        )

    log.info("Opening local SQLite database...")
    await init_db()
    log.info("Local database ready.")

    try:
        await app.start()
        me = await app.get_me()
        log.info("Bot started as @%s (id=%s). Waiting for messages...", me.username, me.id)
        await asyncio.Event().wait()
    finally:
        await app.stop()
        await close_db()


def main() -> None:
    try:
        asyncio.run(_run())
    except KeyboardInterrupt:
        log.info("Shutting down...")


if __name__ == "__main__":
    main()
