"""Entry point for the watermark Telegram bot.

Run from the project root with:

    python -m telegram_bot.main

Make sure API_ID / API_HASH / BOT_TOKEN are set in the project's root `.env`,
install `requirements.txt`, and install ffmpeg on the system.
"""
from __future__ import annotations

import asyncio
import logging
import shutil

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
logging.getLogger("pyrogram").setLevel(logging.WARNING)
log = logging.getLogger("watermark_bot")


async def _run() -> None:
    # Import the Client and handlers while asyncio.run's loop is active.
    # Pyrogram binds its Client and Dispatcher to the current loop at import
    # time; importing them at module scope leaves update workers on a dormant
    # loop, so incoming Telegram messages are never handled correctly.
    from telegram_bot.bot import app
    from telegram_bot.db import close_db, init_db
    from telegram_bot.handlers import media, settings, start, text_input  # noqa: F401

    # Client decorators schedule handler registration on Pyrogram's loop.
    # Yield once so those registrations finish before the dispatcher starts.
    await asyncio.sleep(0)

    if shutil.which("ffmpeg") is None:
        log.warning(
            "ffmpeg was not found on PATH - video watermarking will fail until "
            "you install it (e.g. `sudo apt-get install -y ffmpeg`)."
        )

    log.info("Opening local SQLite database...")
    await init_db()
    log.info("Local database ready.")

    app_started = False
    try:
        await app.start()
        app_started = True
        me = await app.get_me()
        log.info("Bot started as @%s (id=%s). Waiting for messages...", me.username, me.id)
        await asyncio.Event().wait()
    finally:
        try:
            if app_started:
                await app.stop()
        except Exception:  # noqa: BLE001 - always close the local database
            log.exception("Error while stopping the Pyrogram client")
        finally:
            await close_db()


def main() -> None:
    try:
        asyncio.run(_run())
    except KeyboardInterrupt:
        log.info("Shutting down...")


if __name__ == "__main__":
    main()
