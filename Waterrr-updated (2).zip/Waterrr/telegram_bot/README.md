# Watermark Telegram Bot (Pure Python)

A Telegram bot that stamps a customizable watermark (text or logo image) onto
**photos, videos, GIFs and documents**. It uses Pyrogram's MTProto client for
large-file transfers (documented up to **2000 MiB per file** for a bot), rather
than the much smaller standard HTTP Bot API limits. Built in Python with
[Pyrogram](https://docs.pyrogram.org/), Pillow for images and FFmpeg for video.

No HTML / CSS / JavaScript anywhere - this is a standalone Python service,
completely independent from the Next.js placeholder app that lives in the
rest of this repository (that app is only here because the hosting sandbox
requires it; it is not used by the bot in any way).

## Features

- **Text or logo watermarks** - type any text or upload any image/logo.
- **Fully configurable via `/settings`** (stored per user in a local SQLite file):
  - Watermark text
  - Font (10 choices: Poppins, Oswald, Anton, Bebas Neue, Pacifico, Lobster,
    Dancing Script, Open Sans, Courier Stamp; uses system Arial if a font file is absent)
  - Color (10 presets or any custom HEX code)
  - Size (percent of the media's shorter side)
  - Opacity (1-100%)
  - Position (top-left/right, bottom-left/right, center, random)
  - **Animation**: `None`, `📀 DVD Bounce` (the watermark bounces around and
    reflects off every edge, just like the DVD logo screensaver),
    `➡️ Slide In`, `🌫 Fade In`
- **Large file support (up to 2000 MiB per Telegram file transfer)** - videos
  are downloaded, watermarked and uploaded from disk with live progress rather
  than being held entirely in RAM. Leave sufficient free disk space for both
  the original and the re-encoded output.
- Works with photos, videos, GIFs/animations, video notes, and image/video
  documents.
- Sticker feedback: `/start` sends a per-user shuffled welcome sticker, media
  errors send an error sticker, processing stickers are removed when watermarking
  succeeds, and a separate completion sticker follows the delivered result.
  Each pack cycles without repeats until its items have all been used.
- `/start` also shows one of the generated welcome illustrations. The avatar
  artwork is available for a BotFather profile image in `telegram_bot/assets/`.
- Bot text and buttons use Unicode Mathematical Monospace characters to mimic
  the requested typewriter style. Commands, URLs, @mentions and inline code
  remain plain and copyable. This is Unicode styling, not a Telegram font setting.
- The bot uses standard Unicode emoji in text and buttons, but no Telegram
  Premium custom-emoji entities; regular sticker messages remain enabled.
- Users must join the configured channel before settings, media processing or
  other bot features are available. `/start` shows a join button and a
  membership re-check button.

## 1. Requirements

- Python 3.10+ (64-bit on Windows)
- `ffmpeg` and `ffprobe` on the `PATH` (used for video watermarking):
  ```bash
  sudo apt-get update && sudo apt-get install -y ffmpeg
  ```
- No database server is required. The bot creates a local SQLite file at
  `telegram_bot/data/watermark_bot.sqlite3` to store per-user settings and usage
  statistics. The account running the bot must be able to write to the project
  directory. The new SQLite file starts fresh; any old PostgreSQL data is not
  migrated automatically. Stop the bot before manually copying the file for backup.
- A Telegram **API ID** and **API Hash** from <https://my.telegram.org>
  ("API Development Tools").
- A **Bot Token** from [@BotFather](https://t.me/BotFather).

## 2. Install dependencies

From the project root:

```bash
pip install -r requirements.txt
```

## 3. Configure credentials

Copy `.env.example` to `.env` if needed. The local `.env` is ignored by Git and
contains the Telegram credentials/admin configuration for this workspace. Do
not commit it or share its contents. For another deployment, set:

```
API_ID=your_api_id
API_HASH=your_api_hash
BOT_TOKEN=your_bot_token
ADMIN_IDS=your_admin_user_id
CHANNEL_ID=@your_channel
CHANNEL_URL=https://t.me/your_channel
MAX_FILE_SIZE_MB=2000
```

`CHANNEL_ID` and `CHANNEL_URL` enable the force-join gate. Add the bot as an
administrator in the channel so Telegram can reliably verify membership. The
bot checks membership before users can use its watermark features; it does not
copy user media to the channel. Optional tuning variables are also available
in `.env`:

- `ADMIN_IDS` - comma separated Telegram user IDs allowed to run `/stats`.
- `BOT_WORKERS` - concurrent update workers (default `8`).
- `BOT_MAX_CONCURRENT_TRANSMISSIONS` - concurrent up/downloads (default `4`).
- `MAX_FILE_SIZE_MB` - local safety cap in MiB (default `2000`, aligned with Pyrogram's documented bot transfer ceiling).
- `BOT_DB_PATH` - optional path for the local SQLite file; by default it is `telegram_bot/data/watermark_bot.sqlite3`.

## 4. Run the bot

From the project root:

```bash
python -m telegram_bot.main
```

On first run Pyrogram will create a local session file
(`telegram_bot/watermark_bot.session`) - keep it, it lets the bot restart
without re-authenticating.

## 5. Using the bot

1. Open a chat with your bot on Telegram and send `/start`.
2. Send `/settings` to open the configuration panel and set your watermark
   text/logo, font, color, size, opacity, position and animation.
3. Send any photo, video, GIF or document - the bot downloads it, applies
   your watermark (showing a live progress bar), then uploads the result
   back to you.

### Commands

| Command     | Description                                   |
|-------------|------------------------------------------------|
| `/start`    | Welcome sticker/art and channel join check     |
| `/settings` | Open the watermark settings panel              |
| `/cancel`   | Cancel whatever input the bot is waiting for   |
| `/help`     | Show usage help                                |
| `/stats`    | (admins only) show global usage stats          |

## Project layout

```
start.bat                   # one-click Windows bot launcher
watermark-local.bat         # process a server-local file over Telegram's limit
requirements-local.txt      # minimal local processor dependencies
telegram_bot/
├── main.py                 # entry point (python -m telegram_bot.main)
├── local_watermark.py      # local-path processor; bypasses Telegram transfer limits
├── bot.py                  # shared Pyrogram Client instance
├── config.py                # env var loading
├── constants.py             # fonts / colors / positions / animations / defaults
├── db.py                     # local SQLite settings and usage storage
├── assets/                   # generated welcome illustrations and mascot avatar
├── fonts/                    # optional .ttf files; system-font fallback if absent
├── handlers/
│   ├── start.py              # /start /help /cancel /stats
│   ├── settings.py           # /settings + inline keyboard callback logic
│   ├── text_input.py         # captures custom text/color/size/opacity replies
│   └── media.py               # downloads, watermarks, uploads media
├── watermark/
│   ├── image_watermark.py     # Pillow-based watermarking for photos
│   └── video_watermark.py     # ffmpeg-based watermarking for videos/GIFs
└── utils/
    ├── position.py             # shared position/animation math (incl. DVD bounce)
    ├── ffmpeg_utils.py         # async ffmpeg/ffprobe wrappers with progress
    ├── progress.py              # animated progress bar renderer
    ├── stickers.py              # curated sticker packs and rotation
    ├── text_style.py            # Unicode Mathematical Monospace chat styling
    ├── fonts.py                 # bundled/system font lookup for watermarking
    ├── membership.py            # configured-channel membership gate
    ├── keyboards.py             # inline keyboard builders
    └── formatting.py            # settings summary text
```

## Large-file limits and practical setup

This bot uses a **bot token with Pyrogram/MTProto**. Pyrogram documents MTProto
bot transfers up to **2000 MiB per file**. The public HTTP Bot API is much more
limited (currently 20 MB downloads and 50 MB uploads). A Telegram Premium
*user account* can upload files up to 4 GB in Telegram's app, but that Premium
limit does not automatically apply to this bot-token session. See the
[Pyrogram MTProto comparison](https://docs.pyrogram.org/topics/mtproto-vs-botapi),
[Bot API file limits](https://core.telegram.org/bots/api#sending-files), and
[Telegram's Premium announcement](https://telegram.org/blog/700-million-and-premium).

For files up to the bot's MTProto ceiling, attach large media using Telegram's
**Send as File/Document** option (rather than compressed media). The bot
recognizes video documents by MIME type, downloads them to `telegram_bot/downloads`,
FFmpeg writes a watermarked output to `telegram_bot/outputs`, then Pyrogram
uploads that result. Video processing is disk-based; it does not need to hold
the entire video in RAM. Static-image processing uses Pillow and loads decoded
pixels into memory, so unusually huge images need substantially more RAM. Keep
several times the source size free on the server for input, temporary data and
output, and use a 64-bit Windows Server with a 64-bit FFmpeg build. The bot
checks the final output size before upload and cleans up temporary files after
each job.

A file **over 2000 MiB cannot be sent through the Telegram bot by raising
`MAX_FILE_SIZE_MB` or by using RDP**. To watermark such a file anyway, copy it
directly onto the RDP server and use the included local processor:

```bat
watermark-local.bat "D:\Media\source.mkv" "D:\Media\watermarked.mp4" --text "@YourBrand" --color "#FFFFFF" --size 5 --opacity 70 --position bottom_right
```

`watermark-local.bat` creates a virtual environment if needed, installs the
minimal `requirements-local.txt` dependencies, and processes the local input
with FFmpeg. It does not connect to Telegram or PostgreSQL. For video input,
FFmpeg and ffprobe must be on `PATH`. To use a logo, add
`--logo "D:\Media\logo.png"` instead of `--text`. The result stays on the RDP
server and is **not** uploaded to Telegram. If you need to share an output
larger than 2000 MiB, use a file-transfer/storage service or split it; the
bot's Telegram send limit still applies to the output.

## Running the Telegram bot on a Linux RDP server

1. Connect to the Linux server over RDP and open a Terminal. On Ubuntu/Debian,
   install Python 3.10+, FFmpeg, and a fallback font:
   ```bash
   sudo apt update
   sudo apt install -y python3 python3-venv python3-pip ffmpeg fonts-dejavu-core
   python3 --version
   ```
2. From the project root, create a virtual environment and install the bot
   requirements (use `requirements.txt`, not the local-processor-only file):
   ```bash
   cd /path/to/Waterrr
   python3 -m venv .venv
   source .venv/bin/activate
   python -m pip install --upgrade pip
   python -m pip install -r requirements.txt
   ```
3. Create `.env` from `.env.example` if needed, then enter the real Telegram
   API ID/hash, bot token, admin ID(s), and channel settings. No
   `DATABASE_URL` or PostgreSQL service is needed. The bot creates and uses the
   local database file `telegram_bot/data/watermark_bot.sqlite3` on this RDP
   server. Keep the project directory writable and back up that file.
4. Start the bot:
   ```bash
   python -m telegram_bot.main
   ```
   Keep the process running. To survive RDP disconnects, you can run it inside
   `tmux`; detach with Ctrl+B, then D, and reattach using
   `tmux attach -t watermark-bot`.

## Running on a Windows RDP server

1. Install **64-bit Python 3.10+** and a **64-bit FFmpeg** build on the
server. Add FFmpeg's `bin` directory (containing both `ffmpeg.exe` and
`ffprobe.exe`) to the Windows `PATH`. PostgreSQL is not needed; the bot uses a
local SQLite file.
2. Copy/extract the project to the server and create/edit `.env` with the
Telegram credentials. The bot creates `telegram_bot/data/watermark_bot.sqlite3`
and its tables automatically on first start.
3. Double-click `start.bat`. It creates `.venv`, installs `requirements.txt`,
checks FFmpeg, and starts `python -m telegram_bot.main`. Keep the console open;
press Ctrl+C to stop.
4. To start the bot after a reboot, create a Windows Task Scheduler task that
runs `start.bat` at startup or logon and selects **Run whether user is logged
on or not**. The server must remain powered on and have internet access.

### Watermark a file larger than 2000 MiB locally

1. Copy the original file into a folder on the RDP server (for example `D:\Media`). Do not send this oversized file through Telegram to the bot.
2. Open Command Prompt in the project folder and run `watermark-local.bat` with an input path, output path and watermark, for example:
   ```bat
   watermark-local.bat "D:\Media\source.mkv" "D:\Media\watermarked.mp4" --text "@YourBrand"
   ```
3. Wait for FFmpeg's progress to finish. The output is saved at the path you supplied.
4. Open/copy the output from the RDP server. If you need to send it through Telegram, the output must still be within the bot transfer limit; otherwise use cloud/SFTP storage or split the output.

RDP is only remote access to the Windows server; it does not increase Telegram's
file-size limits. Leave several times the input size free on the server disk.

## Running the local processor on a Linux server

RDP is only the remote desktop connection. In the Linux desktop session, open a
Terminal; the same commands also work over SSH. The Windows `watermark-local.bat`
file is not used on Linux.

1. Install Python 3.10 or newer, FFmpeg/ffprobe, and a fallback font. On Ubuntu or
   Debian:
   ```bash
   sudo apt update
   sudo apt install -y python3 python3-venv python3-pip ffmpeg fonts-dejavu-core
   python3 --version
   ffmpeg -version
   ffprobe -version
   ```
   If the installed Python is older than 3.10, use a supported newer Python
   rather than the system version.
2. Copy the large source file directly onto the server using RDP shared-folder
   redirection, SFTP/SCP, or cloud storage. Do not send it through Telegram.
3. From the project root, create and activate a virtual environment and install
   the small local-only dependency set:
   ```bash
   cd /path/to/Waterrr
   python3 -m venv .venv
   source .venv/bin/activate
   python -m pip install --upgrade pip
   python -m pip install -r requirements-local.txt
   ```
4. Run the processor with Linux file paths. Video output must use `.mp4`:
   ```bash
   python -m telegram_bot.local_watermark \
     "/srv/media/input.mkv" "/srv/media/watermarked.mp4" \
     --text "@YourBrand"
   ```
   For a logo, use `--logo "/srv/media/logo.png"` instead of `--text`. For
   static images, choose a `.jpg`, `.jpeg`, `.png`, or `.webp` output filename.
5. Wait for processing to finish; the result stays at the output path on the
   server. The local processor does not need `.env`, a Telegram token, or
   PostgreSQL. Keep ample disk space for video input/output; very large images
   can require substantial RAM.

An output larger than Telegram's bot transfer ceiling must also be shared via
SFTP/SCP or cloud storage (or split) rather than sent back through the bot.
