"""Creates the single shared Pyrogram Client instance used across all handlers."""
from __future__ import annotations

from pyrogram import Client

from telegram_bot.config import (
    API_HASH,
    API_ID,
    BASE_DIR,
    BOT_TOKEN,
    MAX_CONCURRENT_TRANSMISSIONS,
    SESSION_NAME,
    WORKERS,
)

app = Client(
    SESSION_NAME,
    api_id=API_ID,
    api_hash=API_HASH,
    bot_token=BOT_TOKEN,
    workdir=str(BASE_DIR),
    workers=WORKERS,
    max_concurrent_transmissions=MAX_CONCURRENT_TRANSMISSIONS,
)

# In-memory per-user state for the tiny settings "conversation" (waiting for
# the user to type a custom watermark text / hex color / size / opacity, or
# upload a logo image). Kept in memory on purpose - it is transient UI state,
# not a setting itself (those live in local SQLite, see telegram_bot/db.py).
PENDING_INPUT: dict[int, str] = {}
